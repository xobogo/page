# 报价模板 {{变量}} 语法参考

## 基本变量

```
{{variable_name}}    单值替换，如 {{company_name}}、{{quote_date}}
```

## 循环块

```
{{#products}}
| {{name}} | {{spec}} | {{qty}} | {{unit}} | {{unit_price}} | {{subtotal}} |
{{/products}}
```

循环块内变量对 products 数组中每个元素展开，生成多行。

## 条件块

```
{{#if has_discount}}
**折扣说明：** {{discount_desc}}，折扣额 ¥{{discount_amount}}
{{/if}}
```

当变量值为真（非空、非0、非false）时渲染内容。

## 内置变量清单

### 报价方信息
| 变量 | 说明 | 来源 |
|------|------|------|
| `{{company_name}}` | 公司全称 | config.json |
| `{{company_short}}` | 公司简称 | config.json |
| `{{quoter_name}}` | 报价人 | config.json |
| `{{quoter_phone}}` | 报价人电话 | config.json |
| `{{quoter_email}}` | 报价人邮箱 | config.json |

### 客户信息
| 变量 | 说明 | 来源 |
|------|------|------|
| `{{client_name}}` | 客户名称 | 阶段1用户输入 |
| `{{client_contact}}` | 客户联系人 | 阶段1用户输入 |
| `{{client_phone}}` | 客户电话 | 阶段1用户输入 |

### 报价元信息
| 变量 | 说明 | 来源 |
|------|------|------|
| `{{quote_no}}` | 报价单号 | 自动生成 (YYYYMMDD-NN) |
| `{{quote_date}}` | 报价日期 | 自动生成 |
| `{{valid_until}}` | 有效期截止日 | 报价日期 + 30天 |
| `{{delivery_date}}` | 交期 | 阶段1/2用户输入 |
| `{{payment_terms}}` | 付款条件 | 阶段2用户输入 |
| `{{warranty}}` | 质保说明 | 阶段2用户输入 |

### 产品明细 (循环内)
| 变量 | 说明 |
|------|------|
| `{{name}}` | 产品名称/型号 |
| `{{spec}}` | 规格说明 |
| `{{qty}}` | 数量 |
| `{{unit}}` | 单位 |
| `{{unit_price}}` | 单价 |
| `{{discount}}` | 单项折扣说明 |
| `{{subtotal}}` | 小计 (qty × unit_price × discount) |

### 价格汇总
| 变量 | 说明 |
|------|------|
| `{{products[]}}` | 产品明细循环块 |
| `{{subtotal_sum}}` | 产品小计汇总 |
| `{{discount_amount}}` | 整单折扣额 |
| `{{discount_desc}}` | 整单折扣说明 |
| `{{discounted_total}}` | 折扣后合计 |
| `{{tax_rate}}` | 税率 (如 13%) |
| `{{tax_amount}}` | 税费 |
| `{{shipping_fee}}` | 运费 |
| `{{grand_total}}` | 总计 |
| `{{grand_total_cn}}` | 总计（中文大写） |
| `{{service_scope}}` | 服务范围 |
| `{{remarks}}` | 备注 |

### 质检标注
| 变量 | 说明 |
|------|------|
| `{{review_note}}` | 质检标注汇总 (阶段3标注项) |

## 模板解析规则

1. 单值变量：直接替换为对应值
2. 循环变量：需提供数组数据，逐元素渲染循环体内模板
3. 条件变量：根据布尔值决定是否渲染
4. 未匹配变量：保留原样 `{{var}}`，并在输出中高亮警告
5. 中文大写金额：`{{grand_total_cn}}` 需额外生成，格式如"壹万贰仟叁佰肆拾伍元整"
