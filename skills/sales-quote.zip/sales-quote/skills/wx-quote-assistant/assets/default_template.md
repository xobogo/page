# 报价单

**报价方：** {{company_name}}
**报价单号：** {{quote_no}}
**报价日期：** {{quote_date}}
**有效期至：** {{valid_until}}

---

## 客户信息

| 项目 | 内容 |
|------|------|
| 客户名称 | {{client_name}} |
| 联系人 | {{client_contact}} |
| 联系电话 | {{client_phone}} |

---

## 产品明细

| 产品名称 | 规格 | 数量 | 单位 | 单价 | 折扣 | 小计 |
|----------|------|------|------|------|------|------|
{{#products}}
| {{name}} | {{spec}} | {{qty}} | {{unit}} | ¥{{unit_price}} | {{discount_desc}} | ¥{{subtotal}} |
{{/products}}

---

## 价格汇总

| 项目 | 金额 |
|------|------|
| 产品小计 | ¥{{subtotal_sum}} |
{{#if has_discount}}
| 整单折扣 | -¥{{discount_amount}}（{{discount_desc}}） |
{{/if}}
| 折扣后合计 | ¥{{discounted_total}} |
| 运费 | ¥{{shipping_fee}} |
| 税费（{{tax_rate}}） | ¥{{tax_amount}} |
| **总计** | **¥{{grand_total}}** |
| 总计（大写） | {{grand_total_cn}} |

---

## 商务条款

| 项目 | 内容 |
|------|------|
| 交期 | {{delivery_date}} |
| 付款条件 | {{payment_terms}} |
| 质保 | {{warranty}} |
| 服务范围 | {{service_scope}} |

---

## 备注

{{remarks}}

---

> **AI 辅助生成，请人工复核**

---
*报价人：{{quoter_name}} | {{quoter_phone}} | {{quoter_email}}*
*本报价单仅供客户内部评估使用，未经许可不得向第三方披露。*
