---
name: wx-bid-opportunity
description: 帮助企业从海量招中标信息中发现高价值商机，结合企业画像、资质能力、业绩和区域策略，完成标讯搜索、商机筛选、项目解读、投标机会评分、任务拆解和中标复盘。依赖 tender-search Skill 作为标讯数据源。当用户提到"招投标""商机""标讯""投标分析""投标评分""中标复盘""投标任务""招标公告分析""能不能投""商机周报"等关键词，或需要招投标全流程辅助时使用。
agent_created: true
---

# 招投标商机专家

帮助企业从海量招中标信息中发现高价值商机。结合企业画像、资质能力、业绩和区域策略，覆盖标讯搜索→商机筛选→项目解读→投标评分→任务拆解→中标复盘全流程。

## 依赖声明

本 Skill 依赖独立的 `tender-search` Skill 作为标讯数据源。**不直接调用知了标讯 API**，所有标讯查询通过 `tender-search` Skill 完成。

**本 Skill 不提供演示模式或模拟数据**。接口不可用时暂停标讯操作，引导用户恢复依赖。

## 目录结构规则（必须遵守）

### Skill 目录（只读）

Skill 安装目录 `~/.workbuddy/skills/wx-bid-opportunity/` 为**只读源文件**。运行时**不得修改**该目录下的任何文件。所有修改、配置更新必须写入 Userdata 目录。

### Userdata 配置目录（读写，跨平台）

所有持久化配置存放在 WorkBuddy 安装目录下的统一 Userdata 路径：

```
~/.workbuddy/userdata/skill/wx-bid-opportunity/
```

- **macOS/Linux**: `$HOME/.workbuddy/userdata/skill/wx-bid-opportunity/`
- **Windows**: `%USERPROFILE%\\.workbuddy\\userdata\\skill\\wx-bid-opportunity\\`

由 `scripts/init_check.py` 和 `scripts/profile_manager.py` 中的 `get_skill_data_dir()` / `get_config_base_dir()` 统一解析，调用方无需自行拼接路径。

其下子目录结构：
```
config/           # 配置文件（company_profile.json, search_topics.json 等）
templates/        # 从 assets/templates/ 首次使用复制的模板缓存（预留）
```

### 产物目录（当前位置）

所有输出的业务文件保存在工作空间：

```
<workspace>/招投标商机专家/
├── .log/               # API 接口调用日志（按日期分目录）
├── 标讯搜索记录/        # 标讯搜索结果（MD + HTML）
├── 商机筛选/            # 商机筛选表（MD + HTML）
├── 重点项目/            # 重点项目完整方案
├── 中标复盘/            # 中标复盘报告
└── 周报/                # 商机周报
```

## 启动检查（每次调用必须执行）

每次用户调用本 Skill 时，首先按以下顺序执行启动检查：

### 1. 检查企业画像初始化状态（严格拦截）

读取启动信息文件（路径由 `scripts/init_check.py` 的 `get_skill_data_dir()` 解析）：
```
~/.workbuddy/userdata/skill/wx-bid-opportunity/config/initialization_state.json
```

**这是强制前置检查**。如果未完成初始化，任何标讯搜索/商机分析操作都将被拦截。

- 若 `initialized` 为 `true` → 通过，继续后续检查
- 若 `initialized` 为 `false` 或文件不存在 → **直接拦截**，输出以下提示并进入初始化流程：

```
⚠️ 您尚未完成企业画像初始化。

我需要先了解您的企业信息，这样才能做更精准的商机查询与处理。

请选择以下任一方式提供公司信息：
1️⃣ 发送公司介绍资料（宣传册、官网介绍、企查查截图等任何材料）
2️⃣ 直接文字告诉我：公司名称、主营业务、所在城市等基础信息
```

### 2. 检查 tender-search 依赖

检查 `~/.workbuddy/skills/tender-search/SKILL.md` 是否存在。

若不存在，输出引导：

```
检测到标讯接口依赖 tender-search Skill 尚未安装。

请按以下步骤安装：

1. 安装 Skillhub 商店（仅安装 CLI）：
   请参考 https://skillhub.cn/install/skillhub.md 完成安装

2. 通过 Skillhub 安装 tender-search 技能：
   skillhub install tender-search

安装完成后，请重新运行本 Skill。
```

### 3. 验证 tender-search 可用性

调用 `tender-search` Skill 执行轻量测试查询（例如 `search_bids` 带 `keywords: ["测试"]`, `page_size: 1`）。

返回错误的处理：
- `AUTHENTICATION_FAILED` → 提示检查 API Key，暂停
- `INSUFFICIENT_BALANCE` / `QUOTA_EXCEEDED` → 提示充值，暂停
- `RATE_LIMITED` → 提示稍后重试，暂停
- 网络超时/不可达 → 提示检查网络，暂停

全部通过后才进入正常业务流程。

## 意图识别与路由

根据用户输入，识别意图并路由到对应流程：

| 用户说法（示例） | 意图 | 路由 |
|---------|------|------|
| "帮我搭建招投标专家""初始化" | 初始化企业画像 | → 初始化流程 |
| "帮我找项目""搜索标讯""看看有什么商机" | 标讯搜索 | → 检查依赖 → 搜索 |
| "哪些值得跟""筛选一下""生成商机表" | 商机筛选 | → 基于已有结果生成筛选表 |
| "分析这个公告""解读这个项目" | 标讯解读 | → 生成结构化摘要 |
| "能不能投""评分""评估一下" | 投标评分 | → 生成投标机会评分 |
| "怎么准备投标""任务清单" | 任务拆解 | → 生成投标准备任务清单 |
| "出个周报""本周商机汇总" | 商机周报 | → 生成商机周报 |
| "谁中了""复盘""竞品分析" | 中标复盘 | → 竞品分析与复盘 |
| "调整搜索偏好""更新画像" | 配置更新 | → 修改对应配置 |
| 直接粘贴招标公告链接/正文 | 快速分析 | → 跳步处理 |

若意图不明确，列出可能的方向供用户选择。

## 核心流程

> **📌 双格式输出原则（所有流程通用，必须遵守）：**
> 每生成一份 `.md` 报告，必须同步生成对应的 `.html` 版本。
> - 优先使用 `scripts/html_generator.py` 专用函数 + 对应模板生成
> - 对于没有模板的报告类型，手动编写内联 CSS HTML 保存为 `.html`
> - HTML 报告文件名与 MD 文件名保持一致（仅后缀不同）
> - 如暂无法使用 html_generator.py，至少输出手工编写的 HTML 文件

### 流程1：企业画像初始化

触发：首次使用 / 画像不存在 / 用户明确要求。

**启动语**（每次必须完整输出）：

```
⚠️ 您尚未完成企业画像初始化。

我需要先了解您的企业信息，这样才能做更精准的商机查询与处理。

请选择以下任一方式提供公司信息：
1️⃣ 发送公司介绍资料（宣传册、官网介绍、企查查截图、百度百科等任何材料）
2️⃣ 直接文字告诉我：公司名称、主营业务、所在城市等基础信息
```

**处理用户提供的材料**：

如果用户以任何格式发送公司资料（包括但不限于：文字段落、PDF、图片截图、链接、网页URL等）：

- 阅读/提取材料中的企业关键信息
- 结构化填充到 company_profile.json 的对应字段
- 信息不完整的部分标注"需人工确认"
- 向用户回显提取结果，确认是否准确

**主动对话引导**：

如果用户选择文字输入，按以下顺序自然引导，不要一次性抛出所有问题：

1. 先确认基础信息（公司名称、城市、主营业务）
2. 根据基础信息，自然追问资质（行业资质、软著、专利）
3. 根据业务类型，追问业绩和案例
4. 最后确认搜索偏好（区域、预算、排除项）

**信息确认与保存**：

- 所有收集到的信息需回显给用户确认
- 用户确认后保存 `company_profile.json` 到 `~/.workbuddy/userdata/skill/wx-bid-opportunity/config/`
- 使用 `scripts/profile_manager.py markdown` 生成 `company_profile.md` 到同目录
- 更新 `initialization_state.json`
- 使用 `scripts/profile_manager.py validate` 验证必填字段
- 输出完成引导语和下一步操作建议

**默认演示画像**：用户说"先用默认画像"时使用预设数据（见 `references/initialization_flow.md`），但必须追问公司名称。

### 流程2：标讯搜索

前置条件：初始化完成、tender-search 可用。

1. 确认搜索意图（关键词、区域、时间范围）
2. 读取 `~/.workbuddy/userdata/skill/wx-bid-opportunity/config/search_topics.json`
3. 若无自定义关键词，根据企业画像自动构建（参考 `references/tender_search_integration.md`）
4. 调用 `tender-search` Skill 的 `search_bids` 或 `query_bids_advanced`
5. **接口调用必须记录日志**：调用前后使用 `scripts/api_logger.py` 记录输入参数和输出结果
6. 将结果通过 `scripts/bid_formatter.py` 转换为标准化结构（**保留所有可获得的字段**）
7. 使用 `scripts/html_generator.py` 生成精美 HTML 版本
8. 按规范保存到工作空间：

```
招投标商机专家/标讯搜索记录/YYYYMMDD-搜索主题-搜索结果.md
招投标商机专家/标讯搜索记录/YYYYMMDD-搜索主题-搜索结果.html
```

**记录字段要求**：必须包含但不限于以下字段（参考 `scripts/bid_formatter.py` 的 `format_single_bid()`）：

| 分类 | 字段 |
|------|------|
| 直达链接 | `direct_link` - 标讯直达查看链接，**每条记录必须有** |
| 基础标识 | `source_id`, `notice_title`, `notice_type`, `bid_process_desc` |
| 招标方信息 | `buyer`, `buyer_contact`, `buyer_phone`, `buyer_address`, `agency`, `agency_contact`, `agency_phone` |
| 区域与时间 | `region`, `city`, `district`, `publish_date`, `deadline`, `bid_open_time` |
| 金额信息 | `budget_amount`, `bid_amount`, `budget_original`, `bid_amount_original` |
| 中标信息 | `winner`, `winner_contact`, `winner_phone` |
| 项目分类 | `keywords`, `bid_type`, `industry_category`, `project_classification` |
| 原文 | `raw_content`, `summary`, `content_snippet` |

**HTML 生成要求**：
- 使用 `scripts/html_generator.py` 的 `generate_search_result_html()` 生成
- 该方法加载 `assets/templates/output/标讯搜索结果模板.html` 模板，替换占位符后输出
- HTML 包含：Hero头部（标题+日期+公司名）、统计概览卡片、按区域/类型分布条形图、每条标讯的卡片（含**直达链接**）
- 可选参数：`keywords`/`exclude_keywords`（数据概览区展示关键词标签）、`begin_date`/`end_date`（数据范围显示）
- HTML 使用响应式设计，兼容桌面和移动端
- 同时保存 `.md` 和 `.html` 两份文件

**搜索参数构建规则**：
- `keywords`：搜索主题的 keywords，或企业画像的 `primary_keywords`
- `match_modes`：搜索主题配置，默认 `["sm", "title", "fulltext"]`
- `provinces`：搜索主题的 regions，或企业画像的 `focus_regions`
- `bid_process`：搜索主题配置，默认 `[1, 2, 4]`（采购意向/预招标/招标）
- `exclude_keywords`：搜索主题配置，或企业画像配置
- `min_budget`：搜索主题配置，或企业画像的 `min_budget_amount`
- 分页：`page_size` 默认 20，翻页时递增 `page`

**搜索结果为空时**：建议调整关键词、扩大区域、延长日期范围。

### 流程3：商机筛选与排序

基于搜索结果生成商机筛选表：

1. 逐条标讯与企业画像匹配
2. 应用排除规则（`risk_rules.json` 中的 `auto_exclude`）
3. 快速评估业务匹配度（不展开完整评分，只做初筛）
4. 标注风险标签（保证金/付款/资质等）
5. 按推荐优先级排序：强烈建议 > 建议跟进 > 需核实 > 谨慎 > 不建议
6. 使用 `assets/templates/output/商机筛选表模板.md` 生成 MD 报告
7. 使用 `scripts/html_generator.py` 的 `generate_screening_table_html()` 生成 HTML 报告
8. 保存到工作空间：

```
招投标商机专家/商机筛选/YYYYMMDD-商机筛选表.md
招投标商机专家/商机筛选/YYYYMMDD-商机筛选表.html
```

**筛选表记录字段要求**：每条标讯记录必须包含但不限于：

| 字段 | 说明 |
|------|------|
| `direct_link` | **直达查看链接**，点击可跳转到原文 |
| `notice_title` | 公告标题（含直达链接） |
| `notice_type` | 公告类型 |
| `buyer` | 招标方 |
| `region` / `city` | 区域信息 |
| `budget_amount` | 预算金额 |
| `deadline` | 截止日期 |
| `remaining_days` | 剩余天数 |
| `business_match` | 业务匹配度判断 |
| `score` | 快速评分 |
| `recommendation_level` | 推荐级别 |
| `recommendation_reason` | 推荐理由 |
| `risk_flags` | 风险标签列表 |

**HTML 生成要求**：
- 表格按推荐优先级排序，含直达链接
- 顶部统计卡片显示各推荐级别数量
- 响应式设计，表格可横向滚动

筛选维度：
- 业务匹配（产品/服务是否对口）
- 区域匹配（是否在关注区域）
- 预算匹配（是否满足最低阈值）
- 排除项（是否命中排除规则）
- 剩余时间（是否充裕）

### 流程4：单项目深度解读

1. 通过 `tender-search` Skill 的 `get_bid_detail` 获取公告全文
2. 提取并结构化呈现：
   - 快速事实（标题、买方、预算、截止时间等）
   - 资质要求（基本资格、特定资质、业绩要求）
   - 技术/商务要求（采购内容、技术规格、付款、质保等）
   - 关键时间节点
   - 风险初步识别
3. 使用 `assets/templates/output/标讯摘要模板.md` 生成 MD 版报告
4. 使用 `scripts/html_generator.py` 的 `generate_bid_analysis_html()` 生成 HTML 版报告，加载 `assets/templates/output/标讯解读报告模板.html`
5. 分别保存到：
   - `招投标商机专家/重点项目/<项目名称>/标讯解读报告.md`
   - `招投标商机专家/重点项目/<项目名称>/标讯解读报告.html`
6. 同时保存标讯原文到 `标讯原文.md`

### 流程5：投标机会评分

使用7维度加权评分模型，详见 `references/scoring_model_detail.md`。

**评分计算**（使用 `scripts/score_calculator.py`）：

维度 | 权重
-----|-----
业务匹配度 | 20%
资质匹配度 | 20%
业绩匹配度 | 15%
商业价值 | 15%
中标可能性 | 10%
交付可行性 | 10%
风险可控性 | 10%

**评级阈值**：
- 85-100：🟢 强烈建议投标
- 70-84：🔵 建议重点跟进
- 60-69：🟡 需进一步核实
- 40-59：🟠 谨慎考虑
- 0-39：🔴 不建议投标

**评分输出要求**：
1. 总分和评级
2. 7个维度得分明细及简要依据（每个维度1-2句话）
3. 风险项清单
4. 需人工确认事项列表
5. 最终建议和核心理由

**信息缺失处理**：
- 优先使用企业画像已有信息
- 画像中也缺失的 → 使用默认值 50 分
- 在报告中标注"信息不足，使用默认值"
- 加入"需人工确认"列表

报告使用 `assets/templates/output/投标机会评分模板.md` 生成 MD 版。
使用 `scripts/html_generator.py` 的 `generate_bid_scoring_html()` 生成 HTML 版，加载 `assets/templates/output/投标机会评分模板.html`。
分别保存到：
- `招投标商机专家/重点项目/<项目名称>/投标机会评分.md`
- `招投标商机专家/重点项目/<项目名称>/投标机会评分.html`

### 流程6：投标准备任务拆解

按六个角色拆分任务：

角色 | 职责范围
-----|--------
销售负责人 | 客户沟通、踏勘、商务策略
售前/方案负责人 | 方案编写、技术应答
投标专员 | 标书制作、封装、递交
财务负责人 | 保证金、资信证明
交付负责人 | 资源评估、工期计划
老板/决策层 | 定价审批、风险评估、最终决策

每个任务包含：内容说明、截止时间（倒推计算）、所需资料、风险提醒。

检查清单包含：投标函、授权书、保证金、报价、方案、资格证明等。

使用 `assets/templates/output/投标准备任务清单模板.md` 生成 MD 版。
使用 `scripts/html_generator.py` 的 `generate_task_list_html()` 生成 HTML 版，加载 `assets/templates/output/投标准备任务清单模板.html`。
分别保存到：
- `招投标商机专家/重点项目/<项目名称>/投标准备任务清单.md`
- `招投标商机专家/重点项目/<项目名称>/投标准备任务清单.html`

### 流程7：中标复盘与竞品分析

1. 通过 `tender-search` Skill 搜索中标结果（`bid_process: [7, 8]`）
2. 分析竞品中标记录（使用 `find_competitors`、`get_top_suppliers`）
3. 汇总价格区间、竞品策略
4. 分析中标/失标原因
5. 提出画像更新建议（补充资质/业绩/偏好）
6. 使用 `assets/templates/output/中标复盘模板.md` 生成 MD 版
7. 使用 `scripts/html_generator.py` 的 `generate_market_analysis_html()` 生成 HTML 版，加载 `assets/templates/output/中标复盘模板.html`
8. 分别保存到：
   - `招投标商机专家/中标复盘/<复盘主题>.md`
   - `招投标商机专家/中标复盘/<复盘主题>.html`

### 流程8：商机周报

1. 汇总本周搜索记录、重点项目进展
2. 统计关键指标（新发现、建议跟进、已投标、中标）
3. 列出下周即将截止项目
4. 标注风险预警
5. 使用 `assets/templates/output/商机周报模板.md` 生成 MD 版
6. 使用 `scripts/html_generator.py` 的 `generate_weekly_report_html()` 生成 HTML 版，加载 `assets/templates/output/商机周报模板.html`
7. 分别保存到：
   - `招投标商机专家/周报/YYYY年第WW周招投标商机周报.md`
   - `招投标商机专家/周报/YYYY年第WW周招投标商机周报.html`

## 重点项目输出规范

当用户对某一项目进行深入分析（如标讯解读、评分、任务拆解等），且该项目的**评分 >= 70 分**或用户**明确要求"做一个完整方案"**时，必须输出完整的重点项目方案。

### 输出内容

在重点项目目录下创建 `方案/` 子目录，包含：

```
招投标商机专家/重点项目/<项目名称>/
├── 标讯原文.md
├── 标讯解读报告.md
├── 标讯解读报告.html              # HTML 版本
├── 投标机会评分.md
├── 投标机会评分.html              # HTML 版本
├── 投标准备任务清单.md
├── 投标准备任务清单.html           # HTML 版本
├── 方案/
│   ├── 重点项目方案.md      # 完整方案 - MD 版本
│   └── 重点项目方案.html    # 完整方案 - HTML 版本（与 MD 内容一致）
```

### 方案内容要求

重点项目方案必须包含以下章节（使用 `assets/templates/output/重点项目方案模板.md`）：

1. **项目概览** — 项目名称、招标方、预算、区域、关键时间
2. **标讯解读摘要** — 快速事实、资质要求、商务条款
3. **企业与项目匹配分析** — 业务匹配、资质匹配、业绩匹配（含画像引用）
4. **投标评分结果** — 7维度得分、总分、评级
5. **投标准备任务清单** — 6角色分工、甘特图、检查清单
6. **风险分析与应对** — 风险清单、应对措施、需人工确认事项
7. **综合建议与决策** — 最终建议、行动路线、决策时间表

### HTML 生成要求

- 使用 `scripts/html_generator.py` 的 `generate_project_plan_html()`
- 每个章节为一个卡片区块，清晰易读
- 表格数据使用样式化表格显示
- 必须包含项目直达链接
- 标注"需人工确认"事项

## 跳步处理规则

支持用户跳过前置步骤：

| 场景 | 处理 |
|------|------|
| 未初始化就要求搜索 | 输出初始化提示语，引导完成初始化后再搜索 |
| 直接粘贴公告问"能不能投" | 绕过搜索，直接基于公告内容解读和评分。缺失的企业画像字段标注"需人工确认" |
| 要求生成任务清单但无项目 | 要求提供项目名称/链接/公告正文或从已有列表中选择 |
| 要求周报但无搜索记录 | 先搜索，再汇总 |

## 必须标注的事项

以下事项 AI 无法替代人工决策，输出时必须标注 **"需人工确认"**：
- 是否参与投标（最终决策）
- 投标报价金额
- 是否接受特定付款条件
- 是否满足特定资质要求
- 是否投入足够资源编制标书
- 是否承诺特定交付周期
- 最终定价策略
- 是否将某项目案例作为业绩证明

## 数据存储规范

### 持久化配置（Userdata 目录 — 跨平台兼容）

配置文件全部存放在 WorkBuddy 安装目录下的统一路径（由 `scripts/profile_manager.py` 的 `get_config_base_dir()` 解析）：

```
~/.workbuddy/userdata/skill/wx-bid-opportunity/
├── config/
│   ├── company_profile.json        # 企业画像 JSON
│   ├── company_profile.md          # 企业画像 Markdown 可读版
│   ├── search_topics.json          # 搜索主题配置
│   ├── scoring_model.json          # 评分模型权重
│   ├── risk_rules.json             # 风险规则
│   ├── output_preferences.json     # 输出偏好
│   └── initialization_state.json   # 初始化状态追踪
```

> ⚠️ **Skill 安装目录（`~/.workbuddy/skills/wx-bid-opportunity/`）为只读**。任何时候不得向此目录写入任何运行时文件。

### 工作空间业务目录

```
<workspace>/招投标商机专家/
├── .log/                          # API 接口调用日志（按日期分目录）
│   └── YYYY-MM-DD/                # 如 2026-06-17/
│       ├── tender-search.search_bids.jsonl
│       ├── tender-search.get_bid_detail.jsonl
│       └── ...
├── 标讯搜索记录/
│   ├── YYYYMMDD-搜索主题-搜索结果.md    # Markdown 版本
│   └── YYYYMMDD-搜索主题-搜索结果.html  # HTML 版本（与 MD 同步）
├── 商机筛选/
│   ├── YYYYMMDD-商机筛选表.md
│   └── YYYYMMDD-商机筛选表.html
├── 重点项目/
│   └── <项目名称>/
│       ├── 标讯原文.md
│       ├── 标讯解读报告.md
│       ├── 标讯解读报告.html
│       ├── 投标机会评分.md
│       ├── 投标机会评分.html
│       ├── 投标准备任务清单.md
│       ├── 投标准备任务清单.html
│       ├── 风险确认清单.md
│       ├── 项目跟进记录.md
│       └── 方案/
│           ├── 重点项目方案.md
│           └── 重点项目方案.html
├── 中标复盘/
│   ├── <复盘主题>.md
│   └── <复盘主题>.html
└── 周报/
    ├── YYYY年第WW周招投标商机周报.md
    └── YYYY年第WW周招投标商机周报.html
```

## 日志记录

### API 接口调用日志（强制要求）

**所有通过 tender-search Skill 调用的接口，都必须记录输入参数和输出结果。**

使用 `scripts/api_logger.py` 的 `log_tender_search_call()` 方法，记录到：

```
<workspace>/招投标商机专家/.log/<YYYY-MM-DD>/<接口名>.jsonl
```

**记录格式**（JSONL，每行一条）：

| 字段 | 说明 |
|------|------|
| `timestamp` | 调用时间（ISO 8601，含毫秒） |
| `interface` | 接口全名，如 `tender-search.search_bids` |
| `elapsed_ms` | 调用耗时（毫秒） |
| `input` | 输入参数（完整 JSON） |
| `output` | 输出结果（截断到 100KB 以内） |
| `annotation` | 备注（可选） |

**触发时机**：
- `search_bids` / `query_bids_advanced` 调用完成时
- `get_bid_detail` 获取公告详情时
- `search_expiring_projects`、`find_competitors`、`get_top_suppliers` 等分析接口
- 任何 tender-search 接口返回错误时（记录错误信息）

**日志文件命名**：按接口名分开存储，每天一个 JSONL 文件。

### Skill 调用日志

每次 Skill 调用后记录到 `~/.workbuddy/userdata/skill/wx-bid-opportunity/logs/skill_call_log.md`：
- 调用时间
- 触发意图
- 执行步骤摘要
- 使用的工具/tender-search 调用
- 异常信息（如有）

### 画像更新日志

每次画像更新后记录到 `~/.workbuddy/userdata/skill/wx-bid-opportunity/logs/user_profile_update_log.md`：
- 更新时间
- 变更字段
- 变更前后值
- 用户确认状态

## 判断原则

- 区分"已知事实""AI判断""待确认信息""人工决策事项"
- 评分附带依据，不只给分数
- 生成文件包含时间戳和版本信息
- 画像更新前询问是否确认（避免自动覆盖）
- 所有涉及标讯的操作前必须通过 tender-search 健康检查

---

## Resources

### references/
- `initialization_flow.md` — 初始化四轮对话流程详解，包含引导语和默认画像
- `scoring_model_detail.md` — 7维度评分模型详细规则和计算逻辑
- `tender_search_integration.md` — 与 tender-search Skill 的集成规范和参数构建规则
- `error_handling.md` — 错误处理、容错策略、用户提示措辞规范
- `company_profile_fields.md` — 企业画像所有字段的含义和使用场景

### scripts/
- `init_check.py` — 检查初始化状态和依赖可用性
- `profile_manager.py` — 企业画像读取/验证/Markdown生成
- `score_calculator.py` — 7维度加权评分计算
- `bid_formatter.py` — tender-search 返回数据转内部标准化格式（含直达链接、联系方式等完整字段）
- `api_logger.py` — API 接口调用日志记录（JSONL 格式，按日期分目录）
- `html_generator.py` — HTML 报告生成，支持7种报告类型（标讯搜索/商机筛选/标讯解读/投标评分/任务清单/中标复盘/商机周报/重点项目方案），通过模板替换和内联生成

### assets/templates/config/
- `company_profile.json` — 企业画像 JSON 模板
- `scoring_model.json` — 评分模型默认权重和阈值
- `search_topics.json` — 搜索主题默认配置
- `risk_rules.json` — 风险规则自动排除/标记规则
- `output_preferences.json` — 输出偏好配置
- `initialization_state.json` — 初始化状态追踪

### assets/templates/output/
- `标讯摘要模板.md` — 单项目结构化摘要
- `标讯解读报告模板.html` — 标讯解读 HTML 模板
- `商机筛选表模板.md` — 商机筛选与推荐排序（含直达链接）
- `商机筛选表模板.html` — 商机筛选 HTML 模板
- `投标机会评分模板.md` — 7维度评分报告
- `投标机会评分模板.html` — 投标机会评分 HTML 模板
- `投标准备任务清单模板.md` — 六角色任务拆解+甘特图
- `投标准备任务清单模板.html` — 任务清单 HTML 模板
- `中标复盘模板.md` — 竞品分析与复盘
- `中标复盘模板.html` — 中标复盘 HTML 模板
- `商机周报模板.md` — 周度商机汇总
- `商机周报模板.html` — 商机周报 HTML 模板
- `重点项目方案模板.md` — 重点项目完整方案（含7个必选章节）
- `标讯搜索结果模板.html` — 标讯搜索结果 HTML 模板
