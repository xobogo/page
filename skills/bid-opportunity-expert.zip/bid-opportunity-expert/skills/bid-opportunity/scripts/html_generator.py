#!/usr/bin/env python3
"""
招投标商机专家 - HTML 报告生成脚本

将标讯搜索记录、商机筛选表、重点项目方案等数据转换为精美 HTML 报告。
搜索记录 HTML 使用模板文件生成，其余使用内联方式（向后兼容）。
"""

import json
import os
import sys
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Any

# ============================================================
# 模板路径
# ============================================================

SKILL_DIR = Path(__file__).resolve().parent.parent
TEMPLATES_DIR = SKILL_DIR / "assets" / "templates" / "output"


def _get_template_path(template_name: str) -> Path:
    """获取模板文件路径"""
    path = TEMPLATES_DIR / template_name
    if not path.exists():
        raise FileNotFoundError(f"模板文件不存在: {path}")
    return path


def _load_template(template_name: str) -> str:
    """读取模板文件内容"""
    path = _get_template_path(template_name)
    with open(str(path), "r", encoding="utf-8") as f:
        return f.read()


# ============================================================
# 通用 HTML 样式（仅用于筛选项模板和重点项目方案模板）
# ============================================================

CSS_COMMON = """
* { margin: 0; padding: 0; box-sizing: border-box; }
body {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "PingFang SC", "Microsoft YaHei", "Helvetica Neue", Arial, sans-serif;
    background: #f5f7fa;
    color: #333;
    line-height: 1.6;
    padding: 20px;
}
.container {
    max-width: 1200px;
    margin: 0 auto;
    background: #fff;
    border-radius: 12px;
    box-shadow: 0 2px 12px rgba(0,0,0,0.08);
    padding: 30px 35px;
}
.header {
    border-bottom: 3px solid #1a73e8;
    padding-bottom: 20px;
    margin-bottom: 25px;
}
.header h1 {
    font-size: 24px;
    color: #1a1a1a;
    margin-bottom: 8px;
}
.header .meta {
    font-size: 13px;
    color: #888;
}
.header .meta span {
    margin-right: 20px;
}
table {
    width: 100%;
    border-collapse: collapse;
    margin: 15px 0;
    font-size: 14px;
}
table th {
    background: #1a73e8;
    color: #fff;
    padding: 10px 12px;
    text-align: left;
    font-weight: 600;
    white-space: nowrap;
}
table td {
    padding: 10px 12px;
    border-bottom: 1px solid #e8ecf0;
}
table tr:hover { background: #f0f6ff; }
table tr:nth-child(even) { background: #fafbfc; }
table tr:nth-child(even):hover { background: #f0f6ff; }
.badge {
    display: inline-block;
    padding: 2px 8px;
    border-radius: 4px;
    font-size: 12px;
    font-weight: 600;
}
.badge-green { background: #e6f7e6; color: #1a7d1a; }
.badge-blue { background: #e6f0ff; color: #1a5e8a; }
.badge-yellow { background: #fff7e6; color: #8a6d1a; }
.badge-orange { background: #fff0e6; color: #8a4a1a; }
.badge-red { background: #ffe6e6; color: #8a1a1a; }
.badge-gray { background: #f0f0f0; color: #666; }
a { color: #1a73e8; text-decoration: none; }
a:hover { text-decoration: underline; }
.section-title {
    font-size: 18px;
    font-weight: 600;
    color: #1a73e8;
    margin: 25px 0 15px;
    padding-bottom: 8px;
    border-bottom: 2px solid #e8ecf0;
}
.stat-row {
    display: flex;
    gap: 15px;
    flex-wrap: wrap;
    margin: 15px 0;
}
.stat-card {
    background: #f8f9fb;
    border: 1px solid #e8ecf0;
    border-radius: 8px;
    padding: 15px 20px;
    min-width: 120px;
    flex: 1;
}
.stat-card .num {
    font-size: 28px;
    font-weight: 700;
    color: #1a73e8;
}
.stat-card .label {
    font-size: 12px;
    color: #888;
    margin-top: 4px;
}
.project-card {
    background: #f8f9fb;
    border: 1px solid #e8ecf0;
    border-radius: 8px;
    padding: 20px;
    margin-bottom: 15px;
}
.project-card h3 { font-size: 16px; margin-bottom: 10px; }
.project-card h3 a { color: #1a73e8; }
.project-card .info-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
    gap: 8px 20px;
    font-size: 13px;
}
.project-card .info-grid .item { display: flex; }
.project-card .info-grid .item .label { color: #888; min-width: 70px; }
.project-card .info-grid .item .value { color: #333; }
.footer {
    margin-top: 30px;
    padding-top: 15px;
    border-top: 1px solid #e8ecf0;
    font-size: 12px;
    color: #aaa;
    text-align: center;
}
"""


# ============================================================
# 辅助函数
# ============================================================

BAR_COLORS_CYCLE = ["fill-green", "fill-blue", "fill-purple", "fill-orange", "fill-teal", "fill-rose", "fill-gray"]


def _generate_bars_html(data: Dict[str, int], max_key: str = "") -> str:
    """将 {label: count} 字典转换为条形图 HTML。

    data: 如 {"广州": 8, "深圳": 7}
    max_key: 可作为 100% 参考的键名（为空则用最大值自动计算）
    """
    if not data:
        return '<div style="color:#999;font-size:13px">暂无数据</div>'

    max_val = data.get(max_key, 0) if max_key else max(data.values())
    if max_val == 0:
        max_val = 1

    lines = []
    sorted_items = sorted(data.items(), key=lambda x: x[1], reverse=True)
    for i, (label, count) in enumerate(sorted_items):
        pct = round(count / max_val * 100, 1)
        color = BAR_COLORS_CYCLE[i % len(BAR_COLORS_CYCLE)]
        lines.append(f"""
            <div class="bar-row">
              <span class="bar-label">{label}</span>
              <div class="bar-track"><div class="bar-fill {color}" style="width:{pct}%">{count}</div></div>
            </div>""")
    return "\n".join(lines)


def _notice_type_badge(notice_type: str) -> str:
    """为公告类型生成 CSS 类名"""
    badge_map = {
        "采购意向": "badge-intent",
        "预招标": "badge-pre",
        "招标": "badge-bid",
        "招标公告": "badge-bid",
        "变更公告": "badge-change",
        "中标候选人公示": "badge-candidate",
        "中标候选人": "badge-candidate",
        "中标结果": "badge-winner",
        "中标": "badge-winner",
        "合同公告": "badge-contract",
        "验收公告": "badge-other",
        "废标公告": "badge-fail",
        "谈判": "badge-bid",
        "询价": "badge-pre",
    }
    return badge_map.get(notice_type, "badge-other")


def _generate_bid_cards_html(bids: List[Dict]) -> str:
    """将格式化的标讯列表转换为卡片 HTML"""
    if not bids:
        return '<div style="color:#999;font-size:13px;text-align:center;padding:20px;">未搜索到标讯</div>'

    cards = []
    for i, bid in enumerate(bids, 1):
        link = bid.get("direct_link") or bid.get("raw_url") or ""
        title = bid.get("notice_title", "未知")

        # 标题
        title_html = f'<a href="{link}" target="_blank">{title}</a>' if link else title

        # 公告类型标签
        notice_type = bid.get("notice_type", "")
        badge_class = _notice_type_badge(notice_type)
        badge_html = f'<span class="badge {badge_class}">{notice_type}</span>' if notice_type else ""

        # 信息
        region = bid.get("region", "")
        if bid.get("city"):
            region += f" · {bid['city']}"

        budget = bid.get("budget_amount")
        budget_str = f"{budget:.2f} 万元" if budget else "未公开"

        deadline = bid.get("deadline", "")
        buyer = bid.get("buyer", "")
        agency = bid.get("agency", "")
        summary_text = bid.get("summary", "") or bid.get("content_snippet", "") or ""

        # 构建 meta 项
        meta_items = ""
        if region:
            meta_items += f'<span class="meta-item">📍 {region}</span>'
        meta_items += f'<span class="meta-item">💰 {budget_str}</span>'
        if deadline:
            meta_items += f'<span class="meta-item">⏰ {deadline}</span>'
        if buyer:
            meta_items += f'<span class="meta-item">🏛️ {buyer}</span>'
        if agency:
            meta_items += f'<span class="meta-item">🤝 {agency}</span>'

        # 描述
        desc_html = f'<p class="card-desc">{summary_text}</p>' if summary_text else ""

        # 链接按钮
        link_html = f'<a class="card-link" href="{link}" target="_blank">🔗 查看原文 →</a>' if link else ""

        cards.append(f"""
        <div class="bid-card">
          <div class="card-top">
            <span class="idx">{i}</span>
            <span class="title">{title_html}</span>
            {badge_html}
          </div>
          <div class="card-meta">
            {meta_items}
          </div>
          {desc_html}
          {link_html}
        </div>""")

    return "\n".join(cards)


# ============================================================
# 报告生成函数
# ============================================================

def generate_search_result_html(
    search_topic: str,
    bids: List[Dict],
    summary: Dict,
    company_name: str = "",
    generated_at: Optional[str] = None,
    keywords: Optional[List[str]] = None,
    exclude_keywords: Optional[List[str]] = None,
    data_begin_date: str = "",
    data_end_date: str = "",
) -> str:
    """从模板生成标讯搜索记录 HTML 报告

    bids: bid_formatter.py 格式化后的标讯列表
    summary: generate_search_summary() 返回的摘要
    keywords: 搜索用的关键词列表（可选，用于展示）
    exclude_keywords: 排除词列表（可选）
    """
    if not generated_at:
        generated_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    total = summary.get("total", 0)
    budget_range = summary.get("budget_range", {})
    has_link_count = summary.get("has_link_count", 0)
    has_deadline_count = summary.get("has_deadline_count", 0)
    by_type = summary.get("by_type", {})
    by_region = summary.get("by_region", {})

    # 预算字符串
    def _fmt_budget(v):
        if v is None:
            return "-"
        return f"{v:.0f}" if isinstance(v, (int, float)) else str(v)

    budget_min = budget_range.get("min") if budget_range else None
    budget_max = budget_range.get("max") if budget_range else None

    # 日期范围
    data_range = f"{data_begin_date} ~ {data_end_date}" if data_begin_date and data_end_date else generated_at[:10]

    # 提取日期
    search_date = generated_at[:10] if len(generated_at) >= 10 else generated_at

    # 加载模板
    template = _load_template("标讯搜索结果模板.html")

    # 生成各区块
    region_bars = _generate_bars_html(dict(by_region))
    type_bars = _generate_bars_html(dict(by_type))
    bid_cards = _generate_bid_cards_html(bids)

    # 页脚
    footer_text = f"由招投标商机专家 Skill 自动生成 · 数据来源：知了标讯 AI 开放平台 · {search_date}"

    # 替换占位符
    replacements = {
        "{{SEARCH_TOPIC}}": search_topic,
        "{{HERO_SUBTITLE}}": search_topic,
        "{{SEARCH_DATE}}": search_date,
        "{{TOTAL_BIDS}}": str(total),
        "{{COMPANY_NAME}}": company_name or "-",
        "{{LINK_COUNT}}": str(has_link_count),
        "{{DEADLINE_COUNT}}": str(has_deadline_count),
        "{{BUDGET_MIN_STR}}": _fmt_budget(budget_min),
        "{{BUDGET_MAX_STR}}": _fmt_budget(budget_max),
        "{{DATA_RANGE}}": data_range,
        "{{REGION_BARS}}": region_bars,
        "{{TYPE_BARS}}": type_bars,
        "{{BID_CARDS}}": bid_cards,
        "{{FOOTER_TEXT}}": footer_text,
    }

    html = template
    for placeholder, value in replacements.items():
        html = html.replace(placeholder, value)

    return html


def generate_screening_table_html(
    search_topic: str,
    bids: List[Dict],
    company_name: str = "",
    generated_at: Optional[str] = None,
    excluded_bids: Optional[List[Dict]] = None,
) -> str:
    """从模板生成商机筛选表 HTML 报告

    加载 assets/templates/output/商机筛选表模板.html，
    填充统计数据和卡片列表后返回完整 HTML。

    bids: 已筛选后的有效标讯列表（含 recommendation_level, score 等字段）
    excluded_bids: 被排除的标讯列表（可选，用于展示排除原因）
    """
    if not generated_at:
        generated_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    # 加载模板
    template = _load_template("商机筛选表模板.html")

    total = len(bids) + len(excluded_bids) if excluded_bids else len(bids)
    valid_count = len(bids)

    # 按级别统计
    level_counts = {"强烈建议": 0, "建议跟进": 0, "需核实": 0, "谨慎": 0, "不建议": 0}
    for b in bids:
        lvl = b.get("recommendation_level", "需核实")
        if lvl in level_counts:
            level_counts[lvl] += 1
    if excluded_bids:
        for b in excluded_bids:
            lvl = b.get("recommendation_level", "不建议")
            level_counts[lvl] = level_counts.get(lvl, 0) + 1

    strong_cnt = level_counts.get("强烈建议", 0)
    follow_cnt = level_counts.get("建议跟进", 0)
    verify_cnt = level_counts.get("需核实", 0)
    cautious_cnt = level_counts.get("谨慎", 0) + level_counts.get("不建议", 0)

    # 生成卡片
    cards = []
    for i, bid in enumerate(bids, 1):
        link = bid.get("direct_link") or bid.get("raw_url") or ""
        title = bid.get("notice_title", "未知")
        title_html = f'<a href="{link}" target="_blank">{title}</a>' if link else title

        level = bid.get("recommendation_level", "需核实")
        badge_cls = {"强烈建议": "bg-green", "建议跟进": "bg-blue", "需核实": "bg-yellow"}.get(level, "bg-gray")
        score = bid.get("score", "-")
        match = bid.get("business_match", "")
        reason = bid.get("recommendation_reason", "")
        region = bid.get("region", "")
        if bid.get("city"):
            region += f" · {bid['city']}"
        notice_type = bid.get("notice_type", "")
        buyer = bid.get("buyer", "")

        meta_items = ""
        if region:
            meta_items += f'<span class="meta-item">📍 {region}</span>'
        if notice_type:
            meta_items += f'<span class="meta-item">📄 {notice_type}</span>'
        if buyer:
            meta_items += f'<span class="meta-item">🏛️ {buyer}</span>'

        reason_html = f'<span class="reason">{reason}</span>' if reason else ""
        link_html = f'<a class="card-link" href="{link}" target="_blank">🔗 查看原文 →</a>' if link else ""

        cards.append(f"""
        <div class="bid-card">
          <div class="card-top">
            <span class="idx">{i}</span>
            <span class="title">{title_html}</span>
            <span class="badge {badge_cls}">{level} · {score}分</span>
          </div>
          <div class="card-meta">{meta_items}</div>
          <div class="card-desc">{reason_html}</div>
          {link_html}
        </div>""")

    screening_cards = "\n".join(cards)

    # 排除信息
    excluded_summary = ""
    excluded_section = ""
    if excluded_bids and len(excluded_bids) > 0:
        excluded_summary = f"""<div class="card anim d2">
  <div class="card-body" style="padding:12px 20px;">
    <div class="summary-box">
      <strong>⚠️ 已排除 {len(excluded_bids)} 条标讯</strong> — 因行业不匹配（医疗/IT/金融/物业等）自动过滤，详见下方列表。
    </div>
  </div>
</div>"""
        chips = "".join(f'<span class="exclude-chip">{b.get("notice_title","?")[:35]}…</span>' for b in excluded_bids[:8])
        if len(excluded_bids) > 8:
            chips += f'<span class="exclude-chip">+{len(excluded_bids)-8} 条</span>'
        excluded_section = f"""<div class="card anim d3">
  <div class="card-header">
    <span class="icon">🚫</span>
    <h2>已排除项目</h2>
    <span class="tag tag-yellow">{len(excluded_bids)} 条</span>
  </div>
  <div class="card-body">
    <p style="font-size:12px;color:#64748b;margin-bottom:8px;">以下项目因医疗/IT/金融/物业等不相关业务已自动排除：</p>
    <div class="exclude-list">{chips}</div>
  </div>
</div>"""

    search_date = generated_at[:10] if len(generated_at) >= 10 else generated_at

    # 替换占位符
    replacements = {
        "{{SEARCH_TOPIC}}": search_topic,
        "{{COMPANY_NAME}}": company_name or "-",
        "{{GENERATED_AT}}": search_date,
        "{{TOTAL_COUNT}}": str(total),
        "{{VALID_COUNT}}": str(valid_count),
        "{{STRONG_COUNT}}": str(strong_cnt),
        "{{FOLLOW_COUNT}}": str(follow_cnt),
        "{{VERIFY_COUNT}}": str(verify_cnt),
        "{{CAUTIOUS_COUNT}}": str(cautious_cnt),
        "{{SCREENING_CARDS}}": screening_cards,
        "{{EXCLUDED_SUMMARY}}": excluded_summary,
        "{{EXCLUDED_SECTION}}": excluded_section,
    }

    html = template
    for placeholder, value in replacements.items():
        html = html.replace(placeholder, value)

    return html


def generate_bid_scoring_html(
    project_name: str,
    company_name: str = "",
    generated_at: Optional[str] = None,
    total_score: int = 0,
    score_label: str = "",
    score_desc: str = "",
    dimension_rows: str = "",
    risk_badges: str = "",
    final_title: str = "",
    final_desc: str = "",
    reasons: str = "",
    actions: str = "",
) -> str:
    """从模板生成投标机会评分 HTML 报告"""
    if not generated_at:
        generated_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    template = _load_template("投标机会评分模板.html")
    search_date = generated_at[:10] if len(generated_at) >= 10 else generated_at
    reps = {
        "{{PROJECT_NAME}}": project_name, "{{COMPANY_NAME}}": company_name or "-",
        "{{GENERATED_AT}}": search_date, "{{TOTAL_SCORE}}": str(total_score),
        "{{SCORE_LABEL}}": score_label, "{{SCORE_DESC}}": score_desc,
        "{{DIMENSION_ROWS}}": dimension_rows, "{{RISK_BADGES}}": risk_badges,
        "{{FINAL_TITLE}}": final_title, "{{FINAL_DESC}}": final_desc,
        "{{REASONS}}": reasons, "{{ACTIONS}}": actions,
    }
    html = template
    for p, v in reps.items():
        html = html.replace(p, v)
    return html


def generate_weekly_report_html(
    week_label: str = "",
    company_name: str = "",
    generated_at: Optional[str] = None,
    period: str = "",
    stats_boxes: str = "",
    stats_rows: str = "",
    project_count: str = "0",
    project_section: str = "",
    risk_section: str = "",
    upcoming_rows: str = "",
    search_topics: str = "",
    decision_rows: str = "",
) -> str:
    """从模板生成商机周报 HTML 报告"""
    if not generated_at:
        generated_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    template = _load_template("商机周报模板.html")
    search_date = generated_at[:10] if len(generated_at) >= 10 else generated_at
    reps = {
        "{{WEEK_LABEL}}": week_label, "{{COMPANY_NAME}}": company_name or "-",
        "{{GENERATED_AT}}": search_date, "{{PERIOD}}": period,
        "{{STATS_BOXES}}": stats_boxes, "{{STATS_ROWS}}": stats_rows,
        "{{PROJECT_COUNT}}": project_count, "{{PROJECT_SECTION}}": project_section,
        "{{RISK_SECTION}}": risk_section, "{{UPCOMING_ROWS}}": upcoming_rows,
        "{{SEARCH_TOPICS}}": search_topics, "{{DECISION_ROWS}}": decision_rows,
    }
    html = template
    for p, v in reps.items():
        html = html.replace(p, v)
    return html


def generate_task_list_html(
    project_name: str,
    company_name: str = "",
    generated_at: Optional[str] = None,
    buyer: str = "",
    bid_no: str = "",
    deadline_text: str = "",
    warn_text: str = "",
    role_sections: str = "",
    risk_items: str = "",
    checklist: str = "",
    post_bid_tasks: str = "",
) -> str:
    """从模板生成投标准备任务清单 HTML 报告"""
    if not generated_at:
        generated_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    template = _load_template("投标准备任务清单模板.html")
    search_date = generated_at[:10] if len(generated_at) >= 10 else generated_at
    reps = {
        "{{PROJECT_NAME}}": project_name, "{{COMPANY_NAME}}": company_name or "-",
        "{{GENERATED_AT}}": search_date, "{{BUYER}}": buyer, "{{BID_NO}}": bid_no,
        "{{DEADLINE_TEXT}}": deadline_text, "{{WARN_TEXT}}": warn_text,
        "{{ROLE_SECTIONS}}": role_sections, "{{RISK_ITEMS}}": risk_items,
        "{{CHECKLIST}}": checklist, "{{POST_BID_TASKS}}": post_bid_tasks,
    }
    html = template
    for p, v in reps.items():
        html = html.replace(p, v)
    return html


def generate_market_analysis_html(
    title: str,
    subtitle: str = "",
    company_name: str = "",
    generated_at: Optional[str] = None,
    period: str = "",
    keywords: str = "",
    stats: str = "",
    trend_rows: str = "",
    supplier_count: str = "0",
    supplier_list: str = "",
    findings: str = "",
) -> str:
    """从模板生成中标复盘/市场分析 HTML 报告"""
    if not generated_at:
        generated_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    template = _load_template("中标复盘模板.html")
    search_date = generated_at[:10] if len(generated_at) >= 10 else generated_at
    reps = {
        "{{TITLE}}": title, "{{SUBTITLE}}": subtitle,
        "{{COMPANY_NAME}}": company_name or "-", "{{GENERATED_AT}}": search_date,
        "{{PERIOD}}": period, "{{KEYWORDS}}": keywords,
        "{{STATS}}": stats, "{{TREND_ROWS}}": trend_rows,
        "{{SUPPLIER_COUNT}}": supplier_count, "{{SUPPLIER_LIST}}": supplier_list,
        "{{FINDINGS}}": findings,
    }
    html = template
    for p, v in reps.items():
        html = html.replace(p, v)
    return html


def generate_bid_analysis_html(
    project_name: str = "",
    company_name: str = "",
    generated_at: Optional[str] = None,
    hero_label: str = "标讯深度解读",
    project_subtitle: str = "",
    publish_date: str = "",
    deadline_date: str = "",
    project_region: str = "",
    bid_type: str = "",
    bid_link: str = "",
    snapshot_tag_cls: str = "green",
    snapshot_tag: str = "",
    info_grid: str = "",
    qual_tag_cls: str = "green",
    qual_tag: str = "",
    qual_content: str = "",
    match_tag_cls: str = "green",
    match_tag: str = "",
    match_grid: str = "",
    value_cards: str = "",
    deadline_tag_cls: str = "yellow",
    deadline_tag: str = "",
    timeline_items: str = "",
    score_tag_cls: str = "green",
    score_tag: str = "",
    summary_bg: str = "#f0fdf4",
    summary_border: str = "#a7f3d0",
    summary_title_color: str = "#065f46",
    summary_text_color: str = "#047857",
    summary_title: str = "",
    summary_desc: str = "",
    risk_and_confirm: str = "",
    action_tag_cls: str = "yellow",
    action_tag: str = "",
    action_items: str = "",
    footer_text: str = "",
) -> str:
    """从标讯解读报告模板生成精美标讯解读 HTML 报告

    所有参数均为预生成的HTML片段，函数直接填入模板占位符。
    """
    if not generated_at:
        generated_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    template = _load_template("标讯解读报告模板.html")
    search_date = generated_at[:10] if len(generated_at) >= 10 else generated_at
    if not footer_text:
        footer_text = f"由招投标商机专家 Skill 自动生成 · 数据来源：知了标讯 AI 开放平台 · {search_date}"
    reps = {
        "{{HERO_LABEL}}": hero_label, "{{PROJECT_NAME}}": project_name,
        "{{PROJECT_SUBTITLE}}": project_subtitle, "{{PUBLISH_DATE}}": publish_date,
        "{{DEADLINE_DATE}}": deadline_date, "{{PROJECT_REGION}}": project_region,
        "{{BID_TYPE}}": bid_type, "{{COMPANY_NAME}}": company_name or "-",
        "{{BID_LINK}}": bid_link,
        "{{SNAPSHOT_TAG_CLS}}": snapshot_tag_cls, "{{SNAPSHOT_TAG}}": snapshot_tag,
        "{{INFO_GRID}}": info_grid,
        "{{QUAL_TAG_CLS}}": qual_tag_cls, "{{QUAL_TAG}}": qual_tag,
        "{{QUAL_CONTENT}}": qual_content,
        "{{MATCH_TAG_CLS}}": match_tag_cls, "{{MATCH_TAG}}": match_tag,
        "{{MATCH_GRID}}": match_grid,
        "{{VALUE_CARDS}}": value_cards,
        "{{DEADLINE_TAG_CLS}}": deadline_tag_cls, "{{DEADLINE_TAG}}": deadline_tag,
        "{{TIMELINE_ITEMS}}": timeline_items,
        "{{SCORE_TAG_CLS}}": score_tag_cls, "{{SCORE_TAG}}": score_tag,
        "{{SUMMARY_BG}}": summary_bg, "{{SUMMARY_BORDER}}": summary_border,
        "{{SUMMARY_TITLE_COLOR}}": summary_title_color,
        "{{SUMMARY_TEXT_COLOR}}": summary_text_color,
        "{{SUMMARY_TITLE}}": summary_title, "{{SUMMARY_DESC}}": summary_desc,
        "{{RISK_AND_CONFIRM}}": risk_and_confirm,
        "{{ACTION_TAG_CLS}}": action_tag_cls, "{{ACTION_TAG}}": action_tag,
        "{{ACTION_ITEMS}}": action_items,
        "{{FOOTER_TEXT}}": footer_text,
    }
    html = template
    for p, v in reps.items():
        html = html.replace(p, v)
    return html


def generate_project_plan_html(
    project_name: str,
    sections: Dict[str, str],
    company_name: str = "",
    generated_at: Optional[str] = None,
    bid_link: str = "",
) -> str:
    """生成重点项目方案 HTML 报告（内联生成，精美版见bid-analysis命令）

    sections: 章节内容字典，键为章节标题，值为 HTML 内容
    bid_link: 标讯原文链接（可选）
    """
    if not generated_at:
        generated_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    section_html = ""
    for title, content in sections.items():
        section_html += f"""
    <h2 class="section-title">{title}</h2>
    <div style="margin-bottom:20px">{content}</div>"""

    html = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>重点项目方案 - {project_name}</title>
<style>{CSS_COMMON}
.project-card {{ border-left: 4px solid #1a73e8; }}
.risk-high {{ border-left-color: #e53935; }}
.risk-mid {{ border-left-color: #fb8c00; }}
.risk-low {{ border-left-color: #43a047; }}
.info-table td:first-child {{ font-weight: 600; color: #555; width: 140px; }}
</style>
</head>
<body>
<div class="container">
    <div class="header">
        <h1>📌 重点项目方案</h1>
        <div class="meta">
            <span>项目：{project_name}</span>
            <span>企业：{company_name or '-'}</span>
            <span>生成时间：{generated_at}</span>
        </div>
    </div>
    {section_html}
    <div class="footer">
        <p>由招投标商机专家 Skill 自动生成 | ⚠️ 所有评分与分析仅供参考，最终决策请结合实际情况</p>
    </div>
</div>
</body>
</html>"""
    return html


def _get_notice_badge(notice_type: str) -> str:
    """为公告类型生成标签（旧版，保留向后兼容）"""
    badge_map = {
        "采购意向": ("badge-blue", "采购意向"),
        "预招标": ("badge-yellow", "预招标"),
        "招标公告": ("badge-green", "招标公告"),
        "变更公告": ("badge-orange", "变更"),
        "中标候选人公示": ("badge-blue", "中标候选"),
        "中标结果": ("badge-green", "已中标"),
        "合同公告": ("badge-gray", "合同"),
        "验收公告": ("badge-gray", "验收"),
        "废标公告": ("badge-red", "废标"),
    }
    cls, label = badge_map.get(notice_type, ("badge-gray", notice_type))
    return f'<span class="badge {cls}">{label}</span>'


def save_html(content: str, file_path: str) -> str:
    """保存 HTML 文件"""
    path = Path(file_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(str(path), "w", encoding="utf-8") as f:
        f.write(content)
    return str(path)


# ============================================================
# CLI 入口
# ============================================================

def main():
    if len(sys.argv) < 2:
        print("Usage: html_generator.py <command> [args]", file=sys.stderr)
        print("Commands: search-result, screening-table, project-plan, bid-scoring, task-list, market-analysis, weekly-report, bid-analysis", file=sys.stderr)
        sys.exit(1)

    command = sys.argv[1]
    input_data = json.load(sys.stdin)
    output_path = sys.argv[2] if len(sys.argv) > 2 else None

    if command == "search-result":
        html = generate_search_result_html(
            search_topic=input_data.get("search_topic", ""),
            bids=input_data.get("bids", []),
            summary=input_data.get("summary", {}),
            company_name=input_data.get("company_name", ""),
            generated_at=input_data.get("generated_at"),
            keywords=input_data.get("keywords"),
            exclude_keywords=input_data.get("exclude_keywords"),
            data_begin_date=input_data.get("begin_date", ""),
            data_end_date=input_data.get("end_date", ""),
        )
    elif command == "screening-table":
        html = generate_screening_table_html(
            search_topic=input_data.get("search_topic", ""),
            bids=input_data.get("bids", []),
            company_name=input_data.get("company_name", ""),
            generated_at=input_data.get("generated_at"),
            excluded_bids=input_data.get("excluded_bids"),
        )
    elif command == "project-plan":
        html = generate_project_plan_html(
            project_name=input_data.get("project_name", ""),
            sections=input_data.get("sections", {}),
            company_name=input_data.get("company_name", ""),
            generated_at=input_data.get("generated_at"),
            bid_link=input_data.get("bid_link", ""),
        )
    elif command == "bid-analysis":
        html = generate_bid_analysis_html(
            project_name=input_data.get("project_name", ""),
            company_name=input_data.get("company_name", ""),
            generated_at=input_data.get("generated_at"),
            hero_label=input_data.get("hero_label", "标讯深度解读"),
            project_subtitle=input_data.get("project_subtitle", ""),
            publish_date=input_data.get("publish_date", ""),
            deadline_date=input_data.get("deadline_date", ""),
            project_region=input_data.get("project_region", ""),
            bid_type=input_data.get("bid_type", ""),
            bid_link=input_data.get("bid_link", ""),
            snapshot_tag_cls=input_data.get("snapshot_tag_cls", "green"),
            snapshot_tag=input_data.get("snapshot_tag", ""),
            info_grid=input_data.get("info_grid", ""),
            qual_tag_cls=input_data.get("qual_tag_cls", "green"),
            qual_tag=input_data.get("qual_tag", ""),
            qual_content=input_data.get("qual_content", ""),
            match_tag_cls=input_data.get("match_tag_cls", "green"),
            match_tag=input_data.get("match_tag", ""),
            match_grid=input_data.get("match_grid", ""),
            value_cards=input_data.get("value_cards", ""),
            deadline_tag_cls=input_data.get("deadline_tag_cls", "yellow"),
            deadline_tag=input_data.get("deadline_tag", ""),
            timeline_items=input_data.get("timeline_items", ""),
            score_tag_cls=input_data.get("score_tag_cls", "green"),
            score_tag=input_data.get("score_tag", ""),
            summary_bg=input_data.get("summary_bg", "#f0fdf4"),
            summary_border=input_data.get("summary_border", "#a7f3d0"),
            summary_title_color=input_data.get("summary_title_color", "#065f46"),
            summary_text_color=input_data.get("summary_text_color", "#047857"),
            summary_title=input_data.get("summary_title", ""),
            summary_desc=input_data.get("summary_desc", ""),
            risk_and_confirm=input_data.get("risk_and_confirm", ""),
            action_tag_cls=input_data.get("action_tag_cls", "yellow"),
            action_tag=input_data.get("action_tag", ""),
            action_items=input_data.get("action_items", ""),
            footer_text=input_data.get("footer_text", ""),
        )
    elif command == "bid-scoring":
        html = generate_bid_scoring_html(
            project_name=input_data.get("project_name", ""),
            company_name=input_data.get("company_name", ""),
            generated_at=input_data.get("generated_at"),
            total_score=input_data.get("total_score", 0),
            score_label=input_data.get("score_label", ""),
            score_desc=input_data.get("score_desc", ""),
            dimension_rows=input_data.get("dimension_rows", ""),
            risk_badges=input_data.get("risk_badges", ""),
            final_title=input_data.get("final_title", ""),
            final_desc=input_data.get("final_desc", ""),
            reasons=input_data.get("reasons", ""),
            actions=input_data.get("actions", ""),
        )
    elif command == "task-list":
        html = generate_task_list_html(
            project_name=input_data.get("project_name", ""),
            company_name=input_data.get("company_name", ""),
            generated_at=input_data.get("generated_at"),
            buyer=input_data.get("buyer", ""),
            bid_no=input_data.get("bid_no", ""),
            deadline_text=input_data.get("deadline_text", ""),
            warn_text=input_data.get("warn_text", ""),
            role_sections=input_data.get("role_sections", ""),
            risk_items=input_data.get("risk_items", ""),
            checklist=input_data.get("checklist", ""),
            post_bid_tasks=input_data.get("post_bid_tasks", ""),
        )
    elif command == "market-analysis":
        html = generate_market_analysis_html(
            title=input_data.get("title", ""),
            subtitle=input_data.get("subtitle", ""),
            company_name=input_data.get("company_name", ""),
            generated_at=input_data.get("generated_at"),
            period=input_data.get("period", ""),
            keywords=input_data.get("keywords", ""),
            stats=input_data.get("stats", ""),
            trend_rows=input_data.get("trend_rows", ""),
            supplier_count=input_data.get("supplier_count", "0"),
            supplier_list=input_data.get("supplier_list", ""),
            findings=input_data.get("findings", ""),
        )
    elif command == "weekly-report":
        html = generate_weekly_report_html(
            week_label=input_data.get("week_label", ""),
            company_name=input_data.get("company_name", ""),
            generated_at=input_data.get("generated_at"),
            period=input_data.get("period", ""),
            stats_boxes=input_data.get("stats_boxes", ""),
            stats_rows=input_data.get("stats_rows", ""),
            project_count=input_data.get("project_count", "0"),
            project_section=input_data.get("project_section", ""),
            risk_section=input_data.get("risk_section", ""),
            upcoming_rows=input_data.get("upcoming_rows", ""),
            search_topics=input_data.get("search_topics", ""),
            decision_rows=input_data.get("decision_rows", ""),
        )
    else:
        print(f"Unknown command: {command}", file=sys.stderr)
        sys.exit(1)

    if output_path:
        saved = save_html(html, output_path)
        print(f"HTML 已保存: {saved}")
    else:
        sys.stdout.write(html)


if __name__ == "__main__":
    main()
