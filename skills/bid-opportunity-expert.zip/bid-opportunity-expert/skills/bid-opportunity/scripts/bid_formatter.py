#!/usr/bin/env python3
"""
招投标商机专家 - 标讯数据格式化脚本
将 tender-search 返回的原始数据转换为内部标准化结构
"""

import json
import sys
from datetime import datetime
from typing import Dict, List, Optional


def format_single_bid(raw_bid: Dict) -> Dict:
    """将单条原始标讯数据转换为标准化结构（记录尽可能多的字段）"""
    raw_url = raw_bid.get("url", raw_bid.get("source_url", raw_bid.get("bid_url", "")))
    return {
        # === 基础标识 ===
        "source": "tender-search",
        "source_id": raw_bid.get("uniq_key", raw_bid.get("id", "")),
        "notice_title": raw_bid.get("title", raw_bid.get("notice_title", "")).strip(),
        "notice_type": _map_notice_type(raw_bid),
        "notice_type_id": raw_bid.get("bid_process", raw_bid.get("notice_stage", 0)),
        "bid_process_desc": raw_bid.get("bid_process_desc", ""),

        # === 直达查看链接 ===
        "direct_link": raw_url,
        "raw_url": raw_url,
        "source_url": raw_bid.get("source_url", raw_bid.get("bid_url", "")),

        # === 招标方信息 ===
        "buyer": raw_bid.get("buyer", raw_bid.get("purchaser", "")).strip(),
        "buyer_contact": raw_bid.get("buyer_contact", raw_bid.get("contact_person", "")).strip(),
        "buyer_phone": raw_bid.get("buyer_phone", raw_bid.get("contact_phone", "")).strip(),
        "buyer_address": raw_bid.get("buyer_address", raw_bid.get("address", "")).strip(),
        "agency": raw_bid.get("agency", raw_bid.get("agent_org", "")).strip(),
        "agency_contact": raw_bid.get("agency_contact", raw_bid.get("agent_contact", "")).strip(),
        "agency_phone": raw_bid.get("agency_phone", raw_bid.get("agent_phone", "")).strip(),

        # === 区域与时间 ===
        "region": raw_bid.get("region", raw_bid.get("province", "")).strip(),
        "city": raw_bid.get("city", "").strip(),
        "district": raw_bid.get("district", "").strip(),
        "publish_date": raw_bid.get("publish_date", raw_bid.get("publish_time", "")),
        "deadline": raw_bid.get("deadline", raw_bid.get("bid_end_time", raw_bid.get("end_date", ""))),
        "bid_open_time": raw_bid.get("bid_open_time", raw_bid.get("open_time", "")),

        # === 金额信息 ===
        "budget_amount": _parse_amount(raw_bid.get("budget", raw_bid.get("budget_amount"))),
        "bid_amount": _parse_amount(raw_bid.get("bid_amount", raw_bid.get("win_price"))),
        "budget_original": raw_bid.get("budget", raw_bid.get("budget_amount", "")),
        "bid_amount_original": raw_bid.get("bid_amount", raw_bid.get("win_price", "")),

        # === 中标信息 ===
        "winner": raw_bid.get("winner", raw_bid.get("win_company", "")).strip(),
        "winner_contact": raw_bid.get("winner_contact", "").strip(),
        "winner_phone": raw_bid.get("winner_phone", "").strip(),

        # === 项目分类与关键词 ===
        "keywords": raw_bid.get("keywords", []),
        "bid_type": raw_bid.get("bid_type", ""),
        "industry_category": raw_bid.get("industry_category", raw_bid.get("category", "")),
        "project_classification": raw_bid.get("project_classification", raw_bid.get("classification", "")),

        # === 原文内容 ===
        "raw_content": raw_bid.get("content", raw_bid.get("body", "")),
        "summary": raw_bid.get("summary", raw_bid.get("description", ""))[:500],
        "content_snippet": (raw_bid.get("content", raw_bid.get("body", "")) or "")[:300],

        # === 元数据 ===
        "bid_process": raw_bid.get("bid_process", raw_bid.get("notice_stage", 0)),
        "formatted_at": datetime.now().isoformat()
    }


def _map_notice_type(raw: Dict) -> str:
    """映射公告类型"""
    bid_process = raw.get("bid_process", raw.get("notice_stage", 0))
    mapping = {
        1: "采购意向",
        2: "预招标",
        4: "招标公告",
        5: "变更公告",
        6: "中标候选人公示",
        7: "中标结果",
        8: "合同公告",
        9: "验收公告",
        10: "废标公告"
    }
    return mapping.get(bid_process, raw.get("bid_type", raw.get("notice_type", "未知")))


def _parse_amount(value) -> Optional[float]:
    """解析金额，返回万元为单位的数值"""
    if value is None:
        return None
    if isinstance(value, (int, float)):
        return round(float(value), 2)
    if isinstance(value, str):
        # 尝试解析 "XX万元" 格式
        value = value.replace(",", "").replace("，", "").strip()
        for unit, multiplier in [("亿元", 10000), ("万元", 1), ("元", 0.0001)]:
            if unit in value:
                try:
                    return round(float(value.replace(unit, "")) * multiplier, 2)
                except ValueError:
                    pass
        try:
            return round(float(value), 2)
        except ValueError:
            pass
    return None


def format_bid_list(raw_bids: List[Dict]) -> List[Dict]:
    """批量格式化标讯数据"""
    return [format_single_bid(bid) for bid in raw_bids]


def generate_search_summary(formatted_bids: List[Dict]) -> Dict:
    """生成搜索结果摘要统计（含直达链接统计）"""
    total = len(formatted_bids)
    if total == 0:
        return {"total": 0}
    
    types = {}
    regions = {}
    budgets = [b["budget_amount"] for b in formatted_bids if b["budget_amount"]]
    has_link = sum(1 for b in formatted_bids if b.get("direct_link"))
    has_deadline = sum(1 for b in formatted_bids if b.get("deadline"))
    
    for bid in formatted_bids:
        t = bid["notice_type"]
        types[t] = types.get(t, 0) + 1
        
        r = bid["region"]
        regions[r] = regions.get(r, 0) + 1
    
    return {
        "total": total,
        "by_type": types,
        "by_region": regions,
        "has_link_count": has_link,
        "has_deadline_count": has_deadline,
        "budget_range": {
            "min": min(budgets) if budgets else None,
            "max": max(budgets) if budgets else None,
            "avg": round(sum(budgets) / len(budgets), 2) if budgets else None
        },
        "earliest_deadline": min(
            (b["deadline"] for b in formatted_bids if b["deadline"]),
            default=None
        )
    }


def main():
    if len(sys.argv) > 1:
        with open(sys.argv[1]) as f:
            data = json.load(f)
    else:
        data = json.load(sys.stdin)
    
    # Handle both single bid and list
    if isinstance(data, dict):
        if "data" in data:
            # tender-search response wrapper
            raw_bids = data.get("data", [])
            if isinstance(raw_bids, dict):
                raw_bids = raw_bids.get("items", raw_bids.get("list", []))
        else:
            raw_bids = [data]
    elif isinstance(data, list):
        raw_bids = data
    else:
        raw_bids = []
    
    formatted = format_bid_list(raw_bids)
    summary = generate_search_summary(formatted)
    
    output = {
        "bids": formatted,
        "summary": summary,
        "formatted_at": datetime.now().isoformat()
    }
    
    json.dump(output, sys.stdout, ensure_ascii=False, indent=2)


if __name__ == "__main__":
    main()
