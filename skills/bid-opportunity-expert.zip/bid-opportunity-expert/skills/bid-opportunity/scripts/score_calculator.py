#!/usr/bin/env python3
"""
招投标商机专家 - 评分计算脚本
根据评分模型计算投标机会综合评分
"""

import json
import sys
from typing import Dict, List, Optional, Any


def load_scoring_model(model_path: str) -> Dict:
    """加载评分模型配置"""
    with open(model_path) as f:
        return json.load(f)


def score_sub_dimension(sub_dim: Dict, assessment_value: str) -> int:
    """对单个子维度评分"""
    rules = sub_dim.get("scoring_rules", [])
    for rule in rules:
        if assessment_value in rule.get("condition", ""):
            return rule.get("score", 50)
    return 50  # default


def score_dimension(dimension: Dict, assessments: Dict[str, str]) -> Dict:
    """计算单个维度的得分"""
    sub_dimensions = dimension.get("sub_dimensions", [])
    total_score = 0
    
    sub_scores = {}
    for sub in sub_dimensions:
        sub_id = sub["id"]
        sub_weight = sub.get("weight", 1.0)
        assessment = assessments.get(sub_id, "信息不足")
        # 尝试精确匹配，失败则尝试模糊匹配
        sub_score = score_sub_dimension(sub, assessment)
        sub_scores[sub_id] = {
            "score": sub_score,
            "weight": sub_weight,
            "assessment": assessment
        }
        total_score += sub_score * sub_weight
    
    dimension_weight = dimension.get("weight", 0)
    
    return {
        "dimension_id": dimension["id"],
        "dimension_name": dimension["name"],
        "dimension_weight": dimension_weight,
        "raw_score": round(total_score),
        "sub_scores": sub_scores
    }


def calculate_total_score(
    model_path: str,
    assessments: Dict[str, Dict[str, str]]
) -> Dict:
    """计算综合总分"""
    
    model = load_scoring_model(model_path)
    dimensions = model.get("dimensions", [])
    thresholds = model.get("rating_thresholds", {})
    
    dimension_results = []
    total_weighted_score = 0
    
    for dim in dimensions:
        dim_id = dim["id"]
        dim_assessments = assessments.get(dim_id, {})
        result = score_dimension(dim, dim_assessments)
        dimension_results.append(result)
        
        weighted = result["raw_score"] * result["dimension_weight"]
        result["weighted_score"] = round(weighted, 2)
        total_weighted_score += weighted
    
    total_score = round(total_weighted_score)
    
    # Determine rating
    rating_label = "不建议投标"
    rating_action = "放弃或等待条件变化"
    rating_color = "red"
    
    for level_key, level_info in thresholds.items():
        if level_info["min"] <= total_score <= level_info["max"]:
            rating_label = level_info["label"]
            rating_action = level_info["action"]
            rating_color = level_info["color"]
            break
    
    return {
        "total_score": total_score,
        "rating_label": rating_label,
        "rating_color": rating_color,
        "recommended_action": rating_action,
        "dimensions": dimension_results,
        "model_version": model.get("version", "unknown")
    }


def main():
    if len(sys.argv) < 2:
        print("Usage: score_calculator.py <assessments_json_file>", file=sys.stderr)
        sys.exit(1)
    
    assessments_file = sys.argv[1]
    model_path = sys.argv[2] if len(sys.argv) > 2 else None
    
    if model_path is None:
        # Use default model path
        from pathlib import Path
        skill_dir = Path(__file__).parent.parent
        model_path = str(skill_dir / "assets" / "templates" / "config" / "scoring_model.json")
    
    with open(assessments_file) as f:
        assessments = json.load(f)
    
    result = calculate_total_score(model_path, assessments)
    json.dump(result, sys.stdout, ensure_ascii=False, indent=2)


if __name__ == "__main__":
    main()
