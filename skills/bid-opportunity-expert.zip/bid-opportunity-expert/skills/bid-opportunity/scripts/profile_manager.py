#!/usr/bin/env python3
"""
招投标商机专家 - 企业画像管理脚本
用于读取、更新、验证企业画像 JSON 文件
"""

import json
import os
import sys
from pathlib import Path
from datetime import datetime
from typing import Dict, Optional, Any


def get_config_base_dir() -> Path:
    """获取 Skill 持久化配置基础目录（跨平台兼容）

    路径规则：
    - macOS/Linux: ~/.workbuddy/userdata/skill/wx-bid-opportunity/
    - Windows: %USERPROFILE%\\.workbuddy\\userdata\\skill\\wx-bid-opportunity\\
    """
    home = Path.home()
    return home / ".workbuddy" / "userdata" / "skill" / "wx-bid-opportunity"


def get_profile_path() -> Path:
    """获取企业画像文件路径"""
    return get_config_base_dir() / "config" / "company_profile.json"


def get_init_state_path() -> Path:
    """获取初始化状态文件路径"""
    return get_config_base_dir() / "config" / "initialization_state.json"


def ensure_config_dir() -> Path:
    """确保配置目录存在"""
    config_dir = get_config_base_dir() / "config"
    config_dir.mkdir(parents=True, exist_ok=True)
    return config_dir


def load_profile() -> Optional[Dict]:
    """加载企业画像"""
    path = get_profile_path()
    if path.exists():
        with open(path) as f:
            return json.load(f)
    return None


def save_profile(profile: Dict) -> str:
    """保存企业画像"""
    config_dir = ensure_config_dir()
    path = config_dir / "company_profile.json"
    profile["generated_at"] = datetime.now().isoformat()
    with open(path, "w", encoding="utf-8") as f:
        json.dump(profile, f, ensure_ascii=False, indent=2)
    return str(path)


def update_profile_field(field_path: str, value: Any) -> Dict:
    """
    更新画像中的指定字段
    field_path: 用点号分隔的路径，如 "company_basic.company_name"
    """
    profile = load_profile()
    if profile is None:
        return {"error": "企业画像不存在，请先初始化"}
    
    keys = field_path.split(".")
    target = profile
    for key in keys[:-1]:
        if key not in target:
            target[key] = {}
        target = target[key]
    
    old_value = target.get(keys[-1])
    target[keys[-1]] = value
    
    save_profile(profile)
    
    return {
        "field_path": field_path,
        "old_value": old_value,
        "new_value": value,
        "updated": True
    }


def validate_profile(profile: Dict) -> Dict:
    """验证画像完整性"""
    issues = []
    warnings = []
    
    # Check required fields
    basic = profile.get("company_basic", {})
    if not basic.get("company_name"):
        issues.append("缺少公司名称（company_basic.company_name）")
    if not basic.get("city"):
        warnings.append("建议填写公司所在城市")
    if not basic.get("main_business"):
        issues.append("缺少主营业务描述（company_basic.main_business）")
    
    qual = profile.get("qualification_profile", {})
    entities = qual.get("bidding_entities", [])
    if not entities or not any(e.get("entity_name") for e in entities):
        issues.append("缺少投标主体名称（qualification_profile.bidding_entities[].entity_name）")
    
    perf = profile.get("performance_profile", {})
    projects = perf.get("representative_projects", [])
    if not projects:
        warnings.append("未提供代表性项目，可能影响业绩匹配评估")
    
    search = profile.get("search_preferences", {})
    if not search.get("focus_regions"):
        warnings.append("未设置关注区域，将使用公司所在省份作为默认")
    if not search.get("primary_keywords"):
        warnings.append("未设置搜索关键词，将根据主营业务自动生成")
    
    return {
        "valid": len(issues) == 0,
        "issues": issues,
        "warnings": warnings
    }


def generate_markdown_profile(profile: Dict) -> str:
    """根据 JSON 画像生成可读的 Markdown 版本"""
    basic = profile.get("company_basic", {})
    business = profile.get("business_scope", {})
    regions = profile.get("target_regions", {})
    quals = profile.get("qualification_profile", {})
    perf = profile.get("performance_profile", {})
    search = profile.get("search_preferences", {})
    
    md = f"""# 企业画像 - {basic.get('company_name', '未命名')}

> 最后更新：{profile.get('generated_at', '未知')}

## 公司基本信息

| 项目 | 内容 |
|------|------|
| 公司名称 | {basic.get('company_name', '-')} |
| 所在城市 | {basic.get('city', '-')} |
| 所在省份 | {basic.get('province', '-')} |
| 主营业务 | {basic.get('main_business', '-')} |
| 企业类型 | {basic.get('company_type', '-')} |
| 员工规模 | {basic.get('employee_count', '-')} |
| 年营收区间 | {basic.get('annual_revenue_range', '-')} |

## 业务范围

- **核心产品/服务**：{', '.join(business.get('primary_products_services', [])) or '-'}
- **目标客户**：{', '.join(business.get('target_customer_types', [])) or '-'}
- **重点拓展方向**：{', '.join(business.get('key_expansion_directions', [])) or '-'}

## 目标区域

- **主要区域**：{', '.join(regions.get('primary_provinces', [])) or '-'}
- **重点城市**：{', '.join(regions.get('primary_cities', [])) or '-'}
- **可拓展区域**：{', '.join(regions.get('expandable_regions', [])) or '-'}

## 资质能力

"""
    
    for entity in quals.get('bidding_entities', []):
        md += f"- **投标主体**：{entity.get('entity_name', '-')}\n"
    
    md += f"""
- **行业资质**：{', '.join(quals.get('industry_qualifications', [])) or '-'}
- **软著**：{', '.join(quals.get('software_copyrights', [])) or '-'}
- **认证**：{', '.join(quals.get('certifications', [])) or '-'}
- **资质短板**：{', '.join(quals.get('qualification_gaps', [])) or '无'}

## 项目业绩

"""
    
    for proj in perf.get('representative_projects', []):
        md += f"- **{proj.get('project_name', '-')}** | {proj.get('customer_type', '-')} | {proj.get('region', '-')} | {proj.get('contract_amount', '-')}万\n"
    
    md += f"""
- **行业经验**：{', '.join(perf.get('industry_experience', [])) or '-'}
- **交付区域**：{', '.join(perf.get('delivery_regions', [])) or '-'}
- **最大项目金额**：{perf.get('max_project_amount_range', '-')}

## 搜索偏好

- **关键词**：{', '.join(search.get('primary_keywords', [])) or '（待设置）'}
- **关注区域**：{', '.join(search.get('focus_regions', [])) or '（待设置）'}
- **最低预算**：{search.get('min_budget_amount', '-')}万
- **排除词**：{', '.join(search.get('exclude_keywords', [])) or '无'}

---
*由招投标商机专家 Skill 自动生成*
"""
    return md


def main():
    if len(sys.argv) < 2:
        print("Usage: profile_manager.py <command> [args]", file=sys.stderr)
        print("Commands: load, validate, markdown", file=sys.stderr)
        sys.exit(1)
    
    command = sys.argv[1]
    
    if command == "load":
        profile = load_profile()
        if profile:
            json.dump(profile, sys.stdout, ensure_ascii=False, indent=2)
        else:
            print("企业画像不存在", file=sys.stderr)
            sys.exit(1)
    
    elif command == "validate":
        profile = load_profile()
        if profile is None:
            print("企业画像不存在，请先初始化", file=sys.stderr)
            sys.exit(1)
        result = validate_profile(profile)
        json.dump(result, sys.stdout, ensure_ascii=False, indent=2)
    
    elif command == "markdown":
        profile = load_profile()
        if profile is None:
            print("企业画像不存在，请先初始化", file=sys.stderr)
            sys.exit(1)
        md = generate_markdown_profile(profile)
        print(md)
    
    else:
        print(f"Unknown command: {command}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
