#!/usr/bin/env python3
"""
招投标商机专家 - API 接口调用日志记录脚本

记录所有通过 tender-search Skill 调用的接口输入与输出日志。
日志按日期存放：<workspace>/招投标商机专家/.log/<YYYY-MM-DD>/
兼容 Windows 和 macOS 路径。
"""

import json
import os
import sys
import time
import traceback
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, Optional


def get_log_dir(workspace: Optional[str] = None) -> Path:
    """获取日志目录（跨平台兼容）

    路径：<workspace>/招投标商机专家/.log/<YYYY-MM-DD>/

    如果未提供 workspace，尝试自动检测：
    1. 当前工作目录
    2. 如果当前目录在 WorkBuddy 项目内
    """
    if workspace:
        base = Path(workspace)
    else:
        # 尝试自动检测
        cwd = Path.cwd()
        # 查找招投标商机专家目录
        for candidate in [cwd, cwd.parent, cwd.parent.parent]:
            bid_dir = candidate / "招投标商机专家"
            if bid_dir.exists():
                base = candidate
                break
        else:
            base = cwd

    # 确保招投标商机专家目录存在，再创建 .log 子目录
    bid_dir = base / "招投标商机专家"
    date_str = datetime.now().strftime("%Y-%m-%d")
    log_dir = bid_dir / ".log" / date_str
    os.makedirs(str(log_dir), exist_ok=True)
    return log_dir


def log_api_call(
    interface_name: str,
    input_params: Dict[str, Any],
    output_result: Any,
    elapsed_ms: Optional[float] = None,
    workspace: Optional[str] = None,
    annotation: Optional[str] = None
) -> str:
    """记录一次 API 接口调用日志

    参数：
        interface_name: 接口名称（如 search_bids, get_bid_detail）
        input_params: 调用时的输入参数字典
        output_result: 接口返回结果
        elapsed_ms: 调用耗时（毫秒）
        workspace: 工作空间路径（留空自动检测）
        annotation: 备注说明

    返回：
        日志文件路径
    """
    log_dir = get_log_dir(workspace)

    # 统一日志文件命名：接口名按日期汇集
    log_file = log_dir / f"{interface_name}.jsonl"

    if elapsed_ms is None:
        elapsed_ms = 0.0

    # 记录内容：时间戳 + 接口名 + 输入参数 + 输出结果 + 耗时
    # 输出参数做截断保护，避免日志文件过大
    record = {
        "timestamp": datetime.now().isoformat(timespec="milliseconds"),
        "interface": interface_name,
        "elapsed_ms": round(elapsed_ms, 2),
        "input": _truncate_dict(input_params, max_depth=4),
        "output": _truncate_value(output_result, max_bytes=102400),  # 100KB 上限
    }
    if annotation:
        record["annotation"] = annotation

    # 追加写入 JSONL 格式（每行一条 JSON）
    with open(str(log_file), "a", encoding="utf-8") as f:
        f.write(json.dumps(record, ensure_ascii=False, default=str) + "\n")

    return str(log_file)


def log_tender_search_call(
    tool_name: str,
    input_params: Dict[str, Any],
    output_result: Any,
    workspace: Optional[str] = None
) -> str:
    """记录一次 tender-search 接口调用的便捷方法

    参数：
        tool_name: tender-search 工具名（search_bids / get_bid_detail 等）
        input_params: 调用参数
        output_result: 返回结果
        workspace: 工作空间路径

    返回：
        日志文件路径
    """
    interface_name = f"tender-search.{tool_name}"
    return log_api_call(
        interface_name=interface_name,
        input_params=input_params,
        output_result=output_result,
        workspace=workspace
    )


def _truncate_dict(d: Dict, max_depth: int = 4, current_depth: int = 0) -> Dict:
    """递归截断字典，避免无限嵌套"""
    if current_depth >= max_depth:
        return {"__truncated__": True}
    result = {}
    for k, v in d.items():
        result[k] = _truncate_value(v, max_depth=max_depth, current_depth=current_depth)
    return result


def _truncate_value(v: Any, max_bytes: int = 102400, max_depth: int = 4, current_depth: int = 0) -> Any:
    """截断值，防止日志文件过大"""
    if isinstance(v, dict):
        if current_depth >= max_depth:
            return {"__truncated__": True, "__keys__": list(v.keys())[:20]}
        return {k: _truncate_value(vv, max_bytes, max_depth, current_depth + 1) for k, vv in v.items()}
    elif isinstance(v, str):
        if len(v.encode("utf-8")) > max_bytes:
            return v[:max_bytes] + "... [truncated]"
        return v
    elif isinstance(v, (list, tuple)):
        return [_truncate_value(i, max_bytes, max_depth, current_depth) for i in v[:100]]
    return v


def list_log_files(workspace: Optional[str] = None, date: Optional[str] = None) -> list:
    """列出指定日期的日志文件

    参数：
        workspace: 工作空间路径
        date: 日期字符串 YYYY-MM-DD，留空列出所有日期目录
    """
    base = Path(workspace) if workspace else Path.cwd()
    log_base = base / "招投标商机专家" / ".log"

    if not log_base.exists():
        return []

    if date:
        date_dir = log_base / date
        if not date_dir.exists():
            return []
        return sorted([str(p) for p in date_dir.iterdir() if p.is_file() and p.suffix == ".jsonl"])

    # 列出所有日期目录
    return sorted([str(p) for p in log_base.iterdir() if p.is_dir()])


def read_log_file(file_path: str, last_n: int = 50) -> list:
    """读取日志文件，返回最近 N 条记录"""
    records = []
    with open(file_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                try:
                    records.append(json.loads(line))
                except json.JSONDecodeError:
                    continue
    return records[-last_n:]


def main():
    """CLI 入口"""
    if len(sys.argv) < 2:
        print("Usage: api_logger.py <command> [args]", file=sys.stderr)
        print("Commands:", file=sys.stderr)
        print("  log <interface> <input_json> <output_json> [elapsed_ms]", file=sys.stderr)
        print("  list [date]", file=sys.stderr)
        print("  read <file_path> [last_n]", file=sys.stderr)
        sys.exit(1)

    command = sys.argv[1]

    if command == "log":
        if len(sys.argv) < 4:
            print("Usage: api_logger.py log <interface> <input_json> <output_json> [elapsed_ms]", file=sys.stderr)
            sys.exit(1)
        interface = sys.argv[2]
        input_params = json.loads(sys.argv[3])
        output_result = json.loads(sys.argv[4])
        elapsed = float(sys.argv[5]) if len(sys.argv) > 5 else None
        file_path = log_api_call(interface, input_params, output_result, elapsed)
        print(f"日志已记录: {file_path}")

    elif command == "list":
        date = sys.argv[2] if len(sys.argv) > 2 else None
        result = list_log_files(None, date)
        print(json.dumps(result, ensure_ascii=False, indent=2))

    elif command == "read":
        if len(sys.argv) < 3:
            print("Usage: api_logger.py read <file_path> [last_n]", file=sys.stderr)
            sys.exit(1)
        file_path = sys.argv[2]
        last_n = int(sys.argv[3]) if len(sys.argv) > 3 else 50
        records = read_log_file(file_path, last_n)
        print(json.dumps(records, ensure_ascii=False, indent=2, default=str))

    else:
        print(f"Unknown command: {command}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
