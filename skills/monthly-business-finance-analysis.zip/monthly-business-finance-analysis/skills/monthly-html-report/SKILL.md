---
name: monthly-html-report
description: "Generate dashboard-style HTML monthly business finance report, including KPI cards, anomalies, management questions, next-month focus, collaboration tasks, and沉淀口径 sections."
displayName:
  zh: "月度经营 HTML 展示报告"
  en: "Monthly HTML Report"
---

# monthly-html-report｜月度经营 HTML 展示报告 Skill

## 目标

生成适合老板阅读、管理层会议展示和邮件发送的 HTML 看板式报告。HTML 不得只是 Markdown 简单转换。

## 必须展示的区块

1. 顶部标题区；
2. 报告月份、状态、资料完整性；
3. 老板先看这 5 件事；
4. 核心指标卡；
5. 资料完整性说明；
6. 经营异常看板；
7. 预算差异分析；
8. 环比 / 趋势分析；
9. 收入与毛利分析；
10. 费用与预算偏差分析；
11. 应收与现金流风险；
12. 异常指标清单；
13. 管理层追问清单；
14. 下月关注事项；
15. 部门协同任务；
16. 可沉淀的报告模板和分析口径；
17. 人工确认边界；
18. 资料补充提醒。

## HTML 要求

1. 使用卡片、标签、表格、风险等级展示。
2. 风险等级使用红 / 橙 / 黄 / 绿标签。
3. 资料不足必须显著展示。
4. 管理层追问清单必须可直接用于会议。
5. 部门协同任务必须突出责任人、截止时间和检查方式。
6. 可沉淀的口径必须标注"候选"，未确认前不得写入长期规则。
7. CSS 内嵌，不依赖外部资源。
8. 生成完整 HTML：`<!DOCTYPE html>`、`html`、`head`、`meta charset`、`style`、`body`。

## 模板查找优先级

**重要**：生成 HTML 报告时，必须优先使用长期模板作为布局和样式参考：

1. `runtime_config.json` 中的 `template_path` → 当前：`{USER_DATA_DIR}/templates/monthly_business_report_template.html`
2. `{USER_DATA_DIR}/templates/monthly_business_report_template.html`（多 Tab 导航布局，参照 cash-flow-collection-risk 专家模板沉淀）
3. 专家包内置模板；
4. 旧 `{WORK_DIR}` 模板；
5. 自动生成基础模板。

**模板使用规则**：
- HTML 布局结构参考模板（导航标签、卡片样式、情景卡片、结论区等）
- 数据内容根据当月经营数据动态填充，不可复制其他专家的示例数据
- Tab 导航标签根据月度经营报告需求调整
- 如模板中某些区块不适用于月度经营分析，可移除或替换为适用内容

## 模板占位符要求

模板必须支持以下数据区块：

```text
boss_top5_cards
kpi_summary_cards
data_completeness_rows
anomaly_rows
abnormal_indicator_rows
management_question_rows
next_month_focus_rows
collaboration_task_rows
template_method_rows
budget_variance_rows
trend_analysis_rows
revenue_margin_rows
expense_roi_rows
ar_cashflow_rows
confirmation_rows
```

缺失占位符时，必须自动修复模板或生成基础模板。

缺少占位符时，必须自动修复模板或生成基础模板。

## 输出

```text
月度经营分析报告_{月份}.html
```

资料不足时：

```text
月度经营分析报告_{月份}_资料不足版.html
```
