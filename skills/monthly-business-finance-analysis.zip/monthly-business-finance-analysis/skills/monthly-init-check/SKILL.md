---
name: monthly-init-check
description: "Initialize monthly business finance analysis runtime paths, templates, user data directory, logs, and configuration before report generation."
displayName:
  zh: "月度经营分析初始化检查"
  en: "Monthly Init Check"
---

# monthly-init-check｜月度经营分析初始化检查 Skill

## 目标

在月度经营分析专家执行任何完整报告、HTML 报告、日志写入、长期配置读取或邮件发送前，检查并准备运行环境。

## 必须检查

1. `{USER_DATA_DIR}` 是否存在且可写；默认：`~/.workbuddy/user-data/experts/monthly-business-finance-analysis/`。
2. `{USER_DATA_DIR}/runtime_config.json` 是否存在；不存在则创建。
3. `{USER_DATA_DIR}/global/user_preferences.json` 是否存在；不存在则创建空 JSON。
4. `{USER_DATA_DIR}/global/memory_rules.json` 是否存在；不存在则创建空 JSON。
5. `{TENANT_DATA_DIR}` 是否存在；不存在则创建。
6. `{TENANT_DATA_DIR}/data_source_config.json` 是否存在；不存在则创建空 JSON。
7. `{TENANT_DATA_DIR}/memory_rules.json` 是否存在；不存在则创建空 JSON。
8. `{OUTPUT_DIR}` 是否存在；不存在则创建。
9. `{LOG_DIR}` 是否存在；不存在则创建。
10. `{TEMPLATE_PATH}` 是否存在且完整；不存在或残缺时执行模板自举。
11. `{WORK_DIR}` 是否可写；仅用于当前临时文件和 HTML 预览副本。
12. 是否存在旧配置需要迁移。

## 模板自举

模板主文件必须保存为：

```text
{USER_DATA_DIR}/templates/monthly_business_report_template.html
```

**查找/复制顺序**（按优先级执行）：

1. 检查 `{USER_DATA_DIR}/templates/monthly_business_report_template.html` 是否已存在。如果已存在 → 跳过复制，直接使用。
2. 如果不存在，**从专家包内置目录复制**：
   ```bash
   cp {EXPERT_ROOT}/references/monthly_business_report_template.html {USER_DATA_DIR}/templates/monthly_business_report_template.html
   ```
   `{EXPERT_ROOT}` 为：`/Users/wumengqing/.workbuddy/plugins/marketplaces/my-experts/plugins/monthly-business-finance-analysis`
3. 如果专家包目录也没有模板文件 → 查找 `runtime_config.json` 中的 `template_path`；
4. 查找旧 `{WORK_DIR}` 模板；
5. 以上全部失败 → 自动生成基础模板。

**重要规则**：
- `{USER_DATA_DIR}/templates/` 目录为空时，必须优先从专家包 `references/` 目录复制模板，这是模板的源头。
- 模板复制仅在初始化阶段（`{USER_DATA_DIR}/templates/` 目录为空或模板文件不存在）执行，已存在模板时不覆盖。
- 复制完成后更新 `runtime_config.json` 中的 `template_path` 指向 `{USER_DATA_DIR}/templates/monthly_business_report_template.html`。

## 输出

```md
## 初始化检查结果

| 检查项 | 状态 | 路径/说明 |
|---|---|---|

## 运行路径

- USER_DATA_DIR：
- TENANT_DATA_DIR：
- OUTPUT_DIR：
- TEMPLATE_PATH：
- LOG_DIR：
- WORK_DIR：
- PREVIEW_OUTPUT_DIR：

## 需要用户处理的问题

- 无 / 列出问题
```
