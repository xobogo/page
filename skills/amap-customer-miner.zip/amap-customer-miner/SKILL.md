---
name: amap-customer-miner
version: 1.0.0
description: 基于高德地图Place API，根据目标客户画像自动挖掘潜在客户资料，生成Excel客户清单 + HTML拜访建议看板
author: agent_created
trigger:
  - 高德客户挖掘
  - 高德API客户搜索
  - 客户挖掘高德
  - 拜访客户名单
  - 客户拜访看板
  - amap customer
  - 地图搜客户
  - POI客户挖掘
---

# 高德客户挖掘技能 (amap-customer-miner)

## 功能概述

根据目标客户画像（行业、产品线、核心痛点），自动调用高德地图 Place API 搜索潜在客户 POI，经智能分类、多维评分、均衡筛选后，输出：

1. **Excel 客户清单**（带条件格式、优先级标注、筛选器）
2. **HTML 拜访建议看板**（可视化仪表盘：客户类型分布、优先级分布、城市分布、拜访路线建议、跟进策略）

## 使用前提

- 高德地图 API Key（用户需提供，从 https://lbs.amap.com 获取）
- 目标客户画像描述（行业定位、核心产品、目标客户类型等）
- 搜索区域范围（省份/城市列表）

## 执行流程

### Step 1: 收集配置信息

向用户确认以下信息（如果用户已提供则跳过）：

| 参数 | 说明 | 示例 |
|---|---|---|
| `amap_key` | 高德API Key | `f2d3cc3a92daf8d7f52a8807b9119e3a` |
| `customer_profile` | 目标客户画像（可从文件读取） | 餐饮连锁总部、预制菜工厂、调味品同行 |
| `region` | 搜索区域 | 华南（广东/广西/海南/福建） |
| `output_dir` | 输出目录 | 当前工作目录 |
| `company_name` | 客户公司名称 | 百味食品 |

如果用户提供了客户画像文件路径（如 `.md` 或 `.docx`），读取文件内容提取客户类型、核心产品、核心能力等信息。

### Step 2: 生成搜索配置

基于客户画像，自动推导：

- **搜索关键词列表**：从客户类型、核心产品、行业关键词推导
- **搜索城市列表**：从区域范围推导（含城市编码）
- **排除关键词**：通用排除列表 + 行业特定排除
- **客户分类规则**：基于客户画像的客户类型映射
- **评分权重**：根据客户画像调整各维度权重
- **TOP数量和配额**：默认100，可调整

将配置写入 `output_dir/amap_search_config.json`，让用户可审核和微调。

### Step 3: 执行API搜索

调用 `scripts/amap_customer_mine.py`，传入配置文件路径：

```bash
/Users/viltooo/.workbuddy/binaries/python/envs/default/bin/python scripts/amap_customer_mine.py --config output_dir/amap_search_config.json --output output_dir
```

脚本执行流程：
1. 按城市 × 关键词遍历搜索（0.2s间隔防QPS限制）
2. 去重（按POI uid）
3. 排除过滤
4. 客户分类
5. 多维评分（满分20）
6. 智能TOP筛选（类型配额 + 城市上限）
7. 输出 Excel + Markdown

### Step 4: 生成HTML拜访建议看板

基于搜索结果数据，生成一个自包含HTML看板文件，包含：

- **概览统计**：总POI数、有效数、精选数
- **可视化图表**：客户类型饼图、优先级分布条形图、城市分布图
- **P1优先拜访卡片**：高评分客户详情，含拜访建议话术
- **跟进策略矩阵**：不同客户类型的推荐跟进方式
- **拜访路线建议**：按城市分组的拜访路线（可导航）

HTML看板使用 Chart.js + 内联样式，单文件自包含，可直接浏览器打开。

### Step 5: 交付结果

向用户呈现以下文件：

1. `公司名_REGION_TOP100拜访客户_高德API.xlsx` — Excel清单
2. `公司名_REGION_TOP100拜访客户_高德API.md` — Markdown清单
3. `公司名_REGION_拜访建议看板.html` — HTML看板
4. `amap_search_config.json` — 搜索配置（供复用/微调）

## 配置文件格式

```json
{
  "amap_key": "xxx",
  "company_name": "百味食品",
  "region_label": "华南",
  "cities": {
    "广州": "440100",
    "深圳": "440300"
  },
  "keywords": ["餐饮连锁", "预制菜", "中央厨房"],
  "exclude_keywords": ["便利店", "超市", "五金"],
  "retail_indicators": ["批发", "配送中心"],
  "customer_types": {
    "餐饮连锁/餐饮管理": {
      "match": ["餐饮连锁", "餐饮管理", "餐饮有限公司"],
      "weight": 5,
      "quota": 30,
      "pitch": "帮您把厨师好味道做成标准化配方，让每家门店味道统一"
    },
    "预制菜/食品加工工厂": {
      "match": ["预制菜", "食品加工", "食品厂"],
      "weight": 5,
      "quota": 25,
      "pitch": "把复杂配方复合成标准调味方案，让每一批都稳定"
    }
  },
  "high_value_keywords": ["连锁", "集团", "中央厨房", "预制菜"],
  "core_cities": ["广州", "深圳", "佛山", "东莞"],
  "province_keywords": ["广东", "广西", "福建", "海南"],
  "city_cap": 12,
  "top_n": 100,
  "p1_threshold": 14,
  "p2_threshold": 10
}
```

## 评分体系

满分20分，7个维度：

| 维度 | 分值 | 说明 |
|---|---|---|
| 客户类型权重 | 0-5 | 从配置 `customer_types.weight` 取值 |
| 企业属性 | 0-4 | 含"有限公司/股份公司/集团公司" = 4；有地址 = 2 |
| 联系方式 | 0-3 | 有电话号码 = 3 |
| 高价值关键词 | 0-3 | 名称含配置中的高价值词 |
| 区域核心 | 0-1 | 位于配置中的核心城市 |
| 注册企业 | 0-1 | 名称含省份关键词 |
| 零售降分 | -3 | 含零售特征词且非公司 |

优先级：P1（≥p1_threshold），P2（≥p2_threshold），P3（其余）

## 注意事项

1. **API QPS限制**：高德免费Key QPS约5次/秒，脚本已内置0.2s间隔。如频繁报错可增至0.5s。
2. **搜索耗时**：30城×15关键词约8-10分钟，耐心等待。
3. **数据质量**：高德POI数据为企业自行注册，可能存在：地址不全、电话失效、名称变更。建议电话筛选后再实地拜访。
4. **隐私合规**：仅使用公开POI数据，不采集个人隐私信息。

## 依赖

- Python 3.13+（使用 managed runtime）
- 包：`requests`, `pandas`, `openpyxl`
- HTML看板：Chart.js CDN（无需本地安装）
