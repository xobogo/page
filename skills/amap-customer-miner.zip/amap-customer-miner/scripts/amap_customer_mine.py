#!/usr/bin/env python3
"""
高德地图客户挖掘通用脚本 v1.0
基于配置文件驱动，支持任意行业/区域的客户POI搜索、分类、评分和精选
"""
import json
import sys
import argparse
import time
import requests
from datetime import datetime
from pathlib import Path

import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter


def load_config(config_path):
    with open(config_path, "r", encoding="utf-8") as f:
        return json.load(f)


def should_exclude(name, exclude_keywords):
    for kw in exclude_keywords:
        if kw in name:
            return True
    return False


def is_retailish(name, retail_indicators):
    for kw in retail_indicators:
        if kw in name:
            return True
    return False


def has_company_suffix(name):
    return any(w in name for w in ["有限公司", "股份公司", "集团公司", "实业公司"])


def classify_customer(name, search_kw, customer_types):
    combined = name + search_kw
    # 按配置中定义的顺序匹配（越靠前优先级越高）
    for ctype, cfg in customer_types.items():
        for match_word in cfg["match"]:
            if match_word in combined:
                return ctype
    return "其他待确认"


def compute_score(name, city, tel, address, ctype, is_retail, cfg):
    has_tel = bool(tel) and str(tel) not in ["", "nan", "None"]
    is_company = has_company_suffix(name)
    has_addr = bool(address) and str(address) not in ["", "nan", "None"]

    score = 0

    # 1. 客户类型权重 (0-5)
    type_weight = cfg["customer_types"].get(ctype, {}).get("weight", 0)
    score += type_weight

    # 2. 企业属性 (0-4)
    if is_company:
        score += 4
    elif has_addr:
        score += 2

    # 3. 联系方式 (0-3)
    if has_tel:
        score += 3

    # 4. 名称含高价值关键词 (0-3)
    for kw in cfg.get("high_value_keywords", []):
        if kw in name:
            score += 1
            break

    # 5. 区域核心加分 (0-1)
    if city in cfg.get("core_cities", []):
        score += 1

    # 6. 零售/批发降分 (-3)
    if is_retail and not is_company:
        score -= 3

    # 7. 名称含省名加分 (0-1)
    for w in cfg.get("province_keywords", []):
        if w in name:
            score += 1
            break

    return max(score, 0)


def classify_priority(score, cfg):
    p1 = cfg.get("p1_threshold", 14)
    p2 = cfg.get("p2_threshold", 10)
    if score >= p1:
        return "P1-优先拜访"
    elif score >= p2:
        return "P2-电话筛选"
    else:
        return "P3-线索池"


def search_all(cfg):
    all_results = {}
    cities = cfg["cities"]
    keywords = cfg["keywords"]
    api_key = cfg["amap_key"]
    base_url = "https://restapi.amap.com/v3/place/text"

    for city_name in cities:
        print(f"\n{'='*50}")
        print(f"搜索城市: {city_name}")

        for kw in keywords:
            print(f"  关键词: {kw}", end="", flush=True)
            city_results = 0

            for page in range(1, 4):
                params = {
                    "key": api_key,
                    "keywords": kw,
                    "city": city_name,
                    "offset": 25,
                    "page": page,
                    "extensions": "all",
                }
                try:
                    r = requests.get(base_url, params=params, timeout=10)
                    data = r.json()
                    if data.get("status") != "1":
                        print(f" [API:{data.get('info')}]", end="")
                        break
                    pois = data.get("pois", [])
                    if not pois:
                        break
                except Exception as e:
                    print(f" [ERR:{e}]", end="")
                    break

                for poi in pois:
                    name = poi.get("name", "")
                    if should_exclude(name, cfg.get("exclude_keywords", [])):
                        continue
                    uid = poi.get("id", "")
                    if uid in all_results:
                        continue

                    all_results[uid] = {
                        "name": name,
                        "city": city_name,
                        "address": poi.get("address", "") or "",
                        "location": poi.get("location", ""),
                        "tel": poi.get("tel", "") or "",
                        "type": poi.get("type", ""),
                        "typecode": poi.get("typecode", ""),
                        "search_kw": kw,
                    }
                    city_results += 1

                if len(pois) < 25:
                    break
                time.sleep(0.2)

            print(f" -> {city_results}条")
            time.sleep(0.15)
        time.sleep(0.3)

    return all_results


def select_top_n(df, cfg):
    """智能选TOP N：保证类型多样性和地域均衡"""
    result = []
    top_n = cfg.get("top_n", 100)
    city_cap = cfg.get("city_cap", 12)
    city_count = {}

    # 每个类型的目标数量
    type_targets = {}
    for ctype, ccfg in cfg["customer_types"].items():
        type_targets[ctype] = ccfg.get("quota", 10)

    for ctype, target in type_targets.items():
        subset = df[df["customer_type"] == ctype].copy()
        if len(subset) == 0:
            continue

        selected = 0
        for _, row in subset.iterrows():
            city = row["city"]
            if city_count.get(city, 0) >= city_cap:
                continue
            result.append(row)
            city_count[city] = city_count.get(city, 0) + 1
            selected += 1
            if selected >= target:
                break

    # 如果不够top_n，从剩余高分中补
    if len(result) < top_n:
        selected_ids = {r["name"] + r["city"] for r in result}
        remaining = df[~df.apply(lambda r: r["name"] + r["city"] in selected_ids, axis=1)]
        for _, row in remaining.iterrows():
            city = row["city"]
            if city_count.get(city, 0) >= city_cap:
                continue
            result.append(row)
            city_count[city] = city_count.get(city, 0) + 1
            if len(result) >= top_n:
                break

    return pd.DataFrame(result[:top_n])


def write_excel(output, output_path):
    wb = Workbook()
    ws = wb.active
    ws.title = "TOP拜访客户"

    header_font = Font(name="Arial", bold=True, size=11, color="FFFFFF")
    header_fill = PatternFill("solid", fgColor="CC0000")
    header_align = Alignment(horizontal="center", vertical="center", wrap_text=True)

    p1_fill = PatternFill("solid", fgColor="FFE0E0")
    p2_fill = PatternFill("solid", fgColor="FFF8E1")
    p3_fill = PatternFill("solid", fgColor="F5F5F5")

    thin_border = Border(
        left=Side(style="thin", color="D0D0D0"),
        right=Side(style="thin", color="D0D0D0"),
        top=Side(style="thin", color="D0D0D0"),
        bottom=Side(style="thin", color="D0D0D0"),
    )

    for col_idx, col_name in enumerate(output.columns, 1):
        cell = ws.cell(row=1, column=col_idx, value=col_name)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = header_align
        cell.border = thin_border

    body_font = Font(name="Arial", size=10)
    body_align = Alignment(vertical="center", wrap_text=True)

    for row_idx, (_, row) in enumerate(output.iterrows(), 2):
        pri = str(row["拜访优先级"])
        if "P1" in pri:
            row_fill = p1_fill
        elif "P2" in pri:
            row_fill = p2_fill
        else:
            row_fill = p3_fill

        for col_idx, col_name in enumerate(output.columns, 1):
            cell = ws.cell(row=row_idx, column=col_idx, value=row[col_name])
            cell.font = body_font
            cell.alignment = body_align
            cell.fill = row_fill
            cell.border = thin_border

    col_widths = {"公司名称": 38, "城市": 8, "地址": 42, "经纬度": 22,
                  "电话": 20, "客户类型": 22, "拜访优先级": 14, "综合评分": 10,
                  "匹配关键词": 16}
    for col_idx, col_name in enumerate(output.columns, 1):
        ws.column_dimensions[get_column_letter(col_idx)].width = col_widths.get(col_name, 15)

    ws.freeze_panes = "A2"
    ws.auto_filter.ref = f"A1:{get_column_letter(len(output.columns))}{len(output)+1}"

    wb.save(output_path)
    print(f"Excel已保存: {output_path}")


def write_markdown(output, top100, results, cfg, md_path):
    company = cfg["company_name"]
    region = cfg["region_label"]

    with open(md_path, "w", encoding="utf-8") as f:
        f.write(f"# {company}{region}TOP{cfg.get('top_n', 100)}拜访客户名单\n\n")
        f.write(f"> 数据来源: 高德地图Place API\n")
        f.write(f"> 生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"> 搜索范围: {region}{len(cfg['cities'])}城市\n\n")

        f.write("## 筛选逻辑\n\n")
        f.write("- **客户类型**：" + "、".join(cfg["customer_types"].keys()) + "\n")
        f.write("- **综合评分**（满分20）：客户类型权重 + 企业属性 + 联系方式 + 高价值关键词 + 区域核心 + 注册企业 - 零售降分\n")
        f.write(f"- **优先级**：P1(≥{cfg.get('p1_threshold', 14)}分) > P2(≥{cfg.get('p2_threshold', 10)}分) > P3(<P2)\n")
        f.write(f"- **地域均衡**：每个城市上限{cfg.get('city_cap', 12)}条\n\n")

        f.write("## 统计\n\n")
        f.write(f"- 总搜索POI: {len(results)}条（去重后）\n")
        f.write(f"- 精选输出: {len(top100)}条\n\n")

        f.write("### 客户类型分布\n\n")
        for ctype, count in top100["customer_type"].value_counts().items():
            f.write(f"- {ctype}: {count}条\n")

        f.write("\n### 优先级分布\n\n")
        for pri, count in top100["priority"].value_counts().items():
            f.write(f"- {pri}: {count}条\n")

        f.write("\n### 城市分布\n\n")
        for city, count in top100["city"].value_counts().items():
            f.write(f"- {city}: {count}条\n")

        f.write("\n---\n\n## TOP名单\n\n")
        f.write("| # | 公司名称 | 城市 | 地址 | 电话 | 客户类型 | 优先级 | 评分 |\n")
        f.write("|---|---|---|---|---|---|---|---|\n")

        for idx, (_, row) in enumerate(output.iterrows(), 1):
            tel = row["电话"] if row["电话"] and str(row["电话"]) not in ["nan", "None"] else "-"
            f.write(f"| {idx} | {row['公司名称']} | {row['城市']} | {row['地址']} | {tel} | {row['客户类型']} | {row['拜访优先级']} | {row['综合评分']} |\n")

    print(f"Markdown已保存: {md_path}")


def main():
    parser = argparse.ArgumentParser(description="高德地图客户挖掘脚本")
    parser.add_argument("--config", required=True, help="搜索配置JSON文件路径")
    parser.add_argument("--output", required=True, help="输出目录路径")
    args = parser.parse_args()

    cfg = load_config(args.config)
    output_dir = Path(args.output)

    company = cfg["company_name"]
    region = cfg["region_label"]
    top_n = cfg.get("top_n", 100)

    print("=" * 60)
    print(f"{company}{region}地区客户搜索")
    print(f"开始时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 60)

    # 搜索
    results = search_all(cfg)
    print(f"\n去重后POI总数: {len(results)}")

    if not results:
        print("无结果，退出")
        return

    df = pd.DataFrame(results.values())

    # 分类 + 评分
    df["customer_type"] = df.apply(
        lambda r: classify_customer(r["name"], r["search_kw"], cfg["customer_types"]), axis=1
    )
    df["score"] = df.apply(
        lambda r: compute_score(
            r["name"], r["city"], r["tel"], r["address"],
            r["customer_type"], is_retailish(r["name"], cfg.get("retail_indicators", [])),
            cfg
        ), axis=1
    )
    df["priority"] = df["score"].apply(lambda s: classify_priority(s, cfg))

    # 过滤
    df = df[df["customer_type"] != "其他待确认"]
    df = df[df["score"] > 0]
    df = df.sort_values(["score", "name"], ascending=[False, True])

    print(f"\n过滤后有效POI: {len(df)}")
    print(f"\n客户类型分布:")
    print(df["customer_type"].value_counts().to_string())
    print(f"\n优先级分布:")
    print(df["priority"].value_counts().to_string())

    # 精选
    top = select_top_n(df, cfg)
    top = top.sort_values(["score", "customer_type"], ascending=[False, True])
    top.reset_index(drop=True, inplace=True)
    top.index = top.index + 1

    print(f"\n{'='*50}")
    print(f"TOP{top_n} 客户类型分布:")
    print(top["customer_type"].value_counts().to_string())
    print(f"\nTOP{top_n} 优先级分布:")
    print(top["priority"].value_counts().to_string())
    print(f"\nTOP{top_n} 城市分布:")
    print(top["city"].value_counts().to_string())

    # 输出列映射
    output_cols = {
        "name": "公司名称",
        "city": "城市",
        "address": "地址",
        "location": "经纬度",
        "tel": "电话",
        "customer_type": "客户类型",
        "priority": "拜访优先级",
        "score": "综合评分",
        "search_kw": "匹配关键词",
    }
    output = top[list(output_cols.keys())].copy()
    output.columns = [output_cols[c] for c in output_cols.keys()]

    # 写Excel
    xlsx_name = f"{company}_{region}TOP{top_n}拜访客户_高德API.xlsx"
    xlsx_path = str(output_dir / xlsx_name)
    write_excel(output, xlsx_path)

    # 写Markdown
    md_name = f"{company}_{region}TOP{top_n}拜访客户_高德API.md"
    md_path = str(output_dir / md_name)
    write_markdown(output, top, results, cfg, md_path)

    # 写JSON数据（供HTML看板使用）
    json_name = f"{company}_{region}TOP{top_n}_data.json"
    json_path = str(output_dir / json_name)
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump({
            "config": cfg,
            "stats": {
                "total_poi": len(results),
                "valid_poi": len(df),
                "selected": len(top),
                "type_distribution": top["customer_type"].value_counts().to_dict(),
                "priority_distribution": top["priority"].value_counts().to_dict(),
                "city_distribution": top["city"].value_counts().to_dict(),
            },
            "customers": top[["name", "city", "address", "location", "tel",
                             "customer_type", "priority", "score", "search_kw"]].to_dict(orient="records"),
        }, f, ensure_ascii=False, indent=2)
    print(f"JSON数据已保存: {json_path}")

    print(f"\n{'='*60}")
    print("全部完成！")


if __name__ == "__main__":
    main()
