# 面霸（InterviewPro）— 招聘面试专家

端到端招聘面试全流程管理，覆盖JD共创、简历解析与岗位匹配、面试题库生成、评分维度设计、面试记录归档与候选人对比。

## 类型

Agent 型（单个 AI 专家）

## 功能

- **JD 共创**：基于模板交互式生成岗位描述，支持多轮打磨
- **简历分析**：智能解析简历，基于JD能力模型多维度评分匹配
- **面试准备**：自动生成面试题库、评分维度表、红旗风险项
- **面试记录**：结构化归档面试沟通，同步管道状态
- **录用决策**：多候选人对比矩阵 + 录用建议

## 使用示例

- "帮我为「AI产品经理」岗位生成一份完整的JD"
- "分析这份简历，评估候选人与岗位的匹配度"
- "为候选人张三生成面试准备材料，包括面试题和评分维度"
- "帮我对比一下这几个候选人，给个录用建议"

## 头像

头像将自动生成在 `avatars/` 目录下。如需替换为自定义头像，要求：
- 格式：PNG（推荐）或 JPG
- 尺寸：512×512 px
- 大小：单张不超过 500KB

## 安装

将专家包目录放到以下路径：

```
~/.workbuddy/plugins/marketplaces/my-experts/plugins/recruiting-interview-pro/
```

然后运行注册命令使其在 WorkBuddy 中可见：

```bash
python3 scripts/register_expert.py ~/.workbuddy/plugins/marketplaces/my-experts/plugins/recruiting-interview-pro/
```

## 打包分享

```bash
zip -r recruiting-interview-pro.zip recruiting-interview-pro/
```
