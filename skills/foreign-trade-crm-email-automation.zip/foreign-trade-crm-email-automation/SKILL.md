---
name: foreign-trade-crm-email-automation
description: End-to-end foreign trade B2B lead generation and outreach automation skill. Use when the user provides a company profile, product summary, target customer description, website summary, or market direction and wants CodeBuddy to analyze ICP, generate search keywords, choose data platforms/APIs, collect target customers, enrich decision makers/emails, write leads into Feishu Bitable CRM, draft personalized cold emails, connect email accounts, and schedule paced outreach sending with follow-up tracking.
---

# 外贸获客 CRM 入库与邮件自动化 Skill

## 核心目标

当用户输入一个公司简介、产品资料、官网摘要、目标市场或客户方向时，自动串联以下闭环：

1. 分析我方产品和目标用户画像。
2. 生成目标客户搜索关键词和平台/API选择。
3. 抓取或整理目标客户线索。
4. 做客户清洗、分级和背调评分。
5. 补全决策人、职位和邮箱可信度。
6. 生成本地 Excel表格 CRM。
7. 生成专开发性的个性化开发信。
8. 连接邮箱并按节奏定时发送。
9. 回写发送、退信、回复和下一步跟进状态。

## 0. 执行前确认

先确认或从上下文提取这些信息；缺失时用合理假设并标注“待人工确认”：

- 我方公司：公司名、产品、核心优势、目标市场、禁用承诺。
- 目标市场：国家/地区、行业、客户类型、语言偏好。
- 邮箱账号：发件邮箱、SMTP/IMAP服务、已经连接的QQ 邮箱服务。
- 发送策略：每封间隔、每日上限、是否先 dry-run 预览。

禁止在未获得授权码或明确授权前真实发送邮件。发送前必须先 dry-run 检查。

## 1. 从公司资料分析 ICP

输出目标客户画像：

- 客户类型：OEM/ODM、设备制造商、系统集成商、分销商、终端品牌、项目商。
- 行业场景：自助终端、POS硬件、工业HMI、数字标牌、医疗终端、智慧零售等。
- 采购动机：替代供应商、定制开发、稳定供货、项目配套、降本、售后响应。
- 决策人职位：Procurement Manager、Purchasing Manager、Supply Chain Director、VP Operations、Product Manager、CTO、VP Engineering、Founder/Owner。
- 排除对象：明显不相关的餐饮、酒店、娱乐、培训、招聘、纯维修、个人服务等。

## 2. 关键词生成

按“产品词 + 应用词 + 客户类型词 + 地区词”组合关键词。

示例结构：

```text
<application> manufacturer in <country>
<product category> supplier <city>
interactive kiosk manufacturer <country>
POS hardware distributor <country>
industrial touch panel PC integrator <country>
digital signage solution provider <country>
medical kiosk OEM <country>
```

输出至少四组：

- 地图搜索关键词：适合 Google Maps、Apple Maps、高德、行业地图。
- 搜索引擎关键词：适合 Google/Bing 搜索官网与目录页。
- LinkedIn/Apollo关键词：适合公司与人员搜索。
- 目录/展会关键词：适合行业展会、协会、B2B目录。

## 3. 平台与 API 选择

根据任务选择平台，不要用一个平台解决所有问题。

| 目标 | 推荐平台/API | 注意事项 |
|---|---|---|
| 批量发现公司 | Google Maps Places API、Google Search、行业目录、展会目录 | 地图API通常不返回邮箱，只做客户发现 |
| 国内线索采集 | 高德地图、企查查/天眼查（如可用）、行业目录 | 注意地区和行业噪声过滤 |
| 公司基础信息 | 官网、About、Product、Contact、LinkedIn公司页 | 记录公开信息来源 |
| 决策人搜索 | Apollo、LinkedIn、RocketReach、Hunter | 优先采购/供应链/运营/产品/工程职位 |
| 邮箱补全 | Apollo Enrichment、Hunter、官网Contact页 | 标记 verified/probable/unverified |
| CRM沉淀 | 本地 excel表格 Base | Select字段先建 options，邮箱/网址可用文本字段 |
| 邮件发送 | SMTP/IMAP、网易/163、Gmail、企业邮箱 | 需要授权码；控制频率；先 dry-run |

Apollo经验：

- 认证使用 `X-Api-Key`。
- 旧 `/people/search` 可能不可用，优先 `/mixed_people/api_search`。
- 公司名搜索 `q_organization_name` 往往比只用 domain 命中更好。
- 先 People Search，再 People Enrichment 揭示邮箱和验证状态。

## 4. 目标客户抓取字段

每条客户至少沉淀：

- 公司名称
- 官网
- 国家/地区
- 城市
- 客户类型
- 主营产品/服务
- 公开信息摘要
- 来源平台
- 来源链接
- 电话/邮箱/联系页面
- 初步匹配原因
- 噪声风险备注

抓取后先去重：公司名、官网域名、电话三者任一强匹配都应合并。

## 5. 背调评分和开发建议

满分100分：

| 维度 | 分值 |
|---|---:|
| 目标客户类型匹配度 | 25 |
| 产品匹配度 | 25 |
| 联系方式可信度 | 15 |
| 官网/公开信息完整度 | 15 |
| 地区市场优先级 | 10 |
| 开发切入角度清晰度 | 10 |

结论规则：

- 75分以上：建议开发，P1。
- 55-74分：暂缓或P2，补充信息后开发。
- 55分以下：放弃或P3。
- 资料不足时不要虚构，标记“资料不足，待人工确认”。

每条输出：总分、开发建议、推荐切入产品、第一封开发信重点、需要人工确认的信息、写回CRM字段。

## 6. 决策人和邮箱补全

按客户类型选择职位：

- 设备/OEM：Procurement Manager、Supply Chain Director、VP Operations、CTO、VP Engineering。
- POS/终端硬件：Procurement Manager、Operations Director、Product Manager。
- 分销商：Purchasing Manager、Import Manager、Category Manager、VP Sales。
- 商显/方案商：Head of Product、CTO、VP Engineering、Procurement Manager。
- 中小企业：Founder、Owner、CEO、Managing Director。

邮箱可信度：

- Verified：优先发送。
- Probable：建议人工复核或低优先级发送。
- Unverified/泛邮箱：作为备选，不作为高价值联系人首选。

## 7. 生成 Excel 表格文件

推荐字段：

```text
公司名称
官网
国家/地区
城市
客户类型
主营产品/服务
公开信息摘要
来源平台
来源链接
目标客户类型匹配度
产品匹配度
联系方式可信度
官网/公开信息完整度
地区市场优先级
开发切入角度清晰度
总分
开发建议
推荐切入产品
第一封开发信重点
需要人工确认的信息
决策人姓名
决策人职位
决策人邮箱
邮箱验证状态
开发信标题
开发信正文
跟进状态
是否有回复
最近发送时间
最近跟进时间
退信状态
下一步动作
备注
```

执行要点：

- 先读取现有字段，避免重复建字段。
- Select字段先创建或更新 options，再写入记录。
- email/url字段不支持时使用文本字段。
- 批量写入后抽样验证公司名、邮箱、评分、跟进状态。
- 更新既有客户时优先按官网域名或公司名匹配，不要重复插入。

## 8. 个性化开发信生成

首封邮件必须满足：

- 英文为主版本。
- 开头提到对方公司一个具体信息：产品、项目、服务对象、市场、官网描述。
- 只推荐1-2个最匹配产品。
- 专业、简短、直接，建议80-130词。
- 不承诺价格、交期、认证、独家合作；只写可进一步确认。
- 结尾给低压力动作：是否愿意看产品资料、样品参数、配置表。

结构：

```text
Subject: <specific product/application> for <Company>

Hi <Name>,

I noticed <Company> <specific public information>. This seems closely related to <application scenario>.

<Our Company> manufactures <1-2 matched products>. For projects like yours, we may support <capability matched to pain point>. Details such as pricing, lead time and certification can be further confirmed based on your project requirements.

Would you be open to reviewing a short product sheet or sample parameters?

Best regards,
<Signature>
```

二次跟进：不要只问“是否收到”，要新增一个轻量价值点，如型号建议、参数表、应用建议或案例方向。

多语言辅助：英文为主；中东市场可补阿拉伯语，西语市场可补西班牙语；所有非英文版本必须标注“发送前请人工确认”。

## 9. 邮箱连接与定时发送

发送前流程：

1. 检查发件邮箱、SMTP服务器、端口、授权码。
2. 发送一封测试邮件到用户指定测试邮箱。
3. dry-run展示前3-5封：收件人、公司、标题、正文、推荐产品。
4. 用户确认后再真实发送。
5. 控制节奏，例如每5分钟一封，并设置每日上限。
6. 每封发送后写回CRM：跟进状态、最近发送时间、是否退信、下一步动作。

163/网易邮箱提示：通常需要SMTP授权码，不要直接用网页登录密码。

风控规则：

- 新邮箱先小批量2-5封。
- 避免短时间大量同模板邮件。
- 不要给 unverified 邮箱大批量发送。
- 退信率异常时暂停发送并复核邮箱质量。

## 10. 输出格式

执行此 Skill 时，优先输出以下结构：

1. 目标用户画像 ICP。
2. 推荐搜索关键词。
3. 推荐平台/API组合。
4. 客户抓取字段和去重规则。
5. CRM字段映射。
6. 客户评分规则和开发优先级。
7. 决策人/邮箱补全策略。
8. 开发信生成规则和样例。
9. 邮件连接与定时发送计划。
10. 需要用户确认的信息。

## 质量检查清单

- [ ] 是否从公司资料中提炼出ICP？
- [ ] 是否生成了分平台关键词？
- [ ] 是否说明了用哪个平台/API做哪个环节？
- [ ] 是否避免把地图API当邮箱来源？
- [ ] 是否有CRM字段映射和写回规则？
- [ ] 是否有100分背调评分？
- [ ] 是否补全决策人职位和邮箱可信度？
- [ ] 是否每封邮件都有客户具体信息？
- [ ] 是否发送前 dry-run？
- [ ] 是否写回发送与回复状态？
