# 老板经营驾驶舱 Agent

帮老板从增长、客户、商机、应收、现金流等维度看清经营状态，识别风险并推动行动。

## 类型

Agent 型（单个 AI 专家）

## 核心功能

- 周度经营简报生成
- 经营风险预警与红/橙/黄/绿分级
- 经营指标异常解释
- 应收与现金流风险专项分析
- 团队执行与行动清单追踪
- 驾驶舱 HTML 页面原型生成
- 长期关注事项沉淀

## 使用示例

- "帮我生成本周老板经营简报，查看本周经营状态、风险预警和行动清单。"
- "生成老板经营驾驶舱页面原型，包含核心指标、经营风险和行动队列。"
- "分析当前应收账款和现金流风险，给出老板行动建议和追问清单。"

## 头像

头像已自动生成在 `avatars/` 目录下。如需替换为自定义头像，要求：
- 格式：PNG（推荐）或 JPG
- 尺寸：512×512 px
- 大小：单张不超过 500KB

## 安装

将专家包目录放到以下路径：

```
~/.workbuddy/plugins/marketplaces/my-experts/plugins/boss-business-dashboard/
```

然后运行注册命令使其在 WorkBuddy 中可见：

```bash
python3 scripts/register_expert.py ~/.workbuddy/plugins/marketplaces/my-experts/plugins/boss-business-dashboard/
```

## 打包分享

```bash
zip -r boss-business-dashboard.zip boss-business-dashboard/
```
