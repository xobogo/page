#!/usr/bin/env python3
"""
国内客户背调与售前咨询报告生成器

从 report_data.json + config.json 生成双格式 HTML + MD 报告。

跨平台兼容说明：
  - macOS: python3 generate_report.py data.json config.json ./output
  - Windows: python generate_report.py data.json config.json ./output
  - 所有路径使用 os.path 处理，无需硬编码分隔符
  - 文件名过滤兼容 Windows 非法字符集

Usage:
    python3 generate_report.py <report_data_path> [config_path] [output_dir]

Args:
    report_data_path: AI 生成的报告数据 JSON 路径
    config_path:    用户配置文件路径（可选，默认 WorkBuddy 用户数据目录）
    output_dir:     输出目录（可选，默认当前目录）
"""

import json
import os
import sys
import html as html_module
from datetime import datetime
from tempfile import gettempdir


# ──────────────────────────────
# 跨平台路径工具
# ──────────────────────────────

def default_skill_userdata(*segments):
    """
    返回 WorkBuddy 用户数据目录下的跨平台路径。

    在 macOS 上: ~/.workbuddy/userdata/skill/...
    在 Windows 上: %USERPROFILE%/.workbuddy/userdata/skill/...
    """
    base = os.path.expanduser("~/.workbuddy/userdata/skill")
    return os.path.join(base, *segments)


def read_json(path):
    """读取 JSON 文件，不存在时返回空字典"""
    if not os.path.exists(path):
        print(f"[WARN] 文件不存在: {path}")
        return {}
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def make_slug(name):
    """从公司名生成合法文件名片段（兼容 Windows + macOS 非法字符集）"""
    for ch in r'\/:*?"<>|':
        name = name.replace(ch, "")
    return name.strip() or "客户报告"


# ──────────────────────────────
# 风险等级工具
# ──────────────────────────────

LEVEL_EMOJI = {"🟢": "🟢", "🟡": "🟡", "🔴": "🔴", "green": "🟢", "yellow": "🟡", "red": "🔴"}
LEVEL_LABEL = {"🟢": "低", "🟡": "中", "🔴": "高"}
LEVEL_COLOR = {"🟢": "#28a745", "🟡": "#ffc107", "🔴": "#dc3545"}
LEVEL_COLOR_LIGHT = {"🟢": "#e6f9ec", "🟡": "#fff8e1", "🔴": "#fce4e4"}
LEVEL_TAG_CLASS = {"🟢": "tag-green", "🟡": "tag-yellow", "🔴": "tag-red"}


def risk_badge(level_emoji):
    """生成风险标识 HTML"""
    emoji = LEVEL_EMOJI.get(level_emoji, level_emoji)
    label = LEVEL_LABEL.get(emoji, "")
    color = LEVEL_COLOR.get(emoji, "#6c757d")
    return f'<span class="risk-badge risk-{emoji}" style="background:{color}20;color:{color};border:1px solid {color}40;">{emoji} {label}</span>'


# ──────────────────────────────
# Markdown 生成
# ──────────────────────────────

def render_md(data, my_company):
    """生成 Markdown 格式报告"""
    lines = []
    c = data.get("company_name", "目标公司")

    # 封面
    lines.append(f"# {c} 客户背调与售前咨询报告\n")
    lines.append(f"> **生成时间**：{datetime.now().strftime('%Y-%m-%d %H:%M')}")
    lines.append(f"> **数据来源**：{data.get('research_source', 'websearch')}\n")
    lines.append("---\n")

    # 1. 客户概览
    lines.append("## 一、客户概览\n")
    bi = data.get("basic_info", {})
    lines.append("| 项目 | 内容 |")
    lines.append("|------|------|")
    for k, v in bi.items():
        lines.append(f"| {k} | {v} |")
    lines.append("")

    # 2. 股东与集团背景
    lines.append("## 二、股东与集团背景\n")
    lines.append(f"- **股权结构**：{data.get('shareholder_structure', '暂无数据')}")
    lines.append("")

    # 3. 行业与业务分析
    lines.append("## 三、行业与业务分析\n")
    biz = data.get("business", {})
    if isinstance(biz, dict):
        for k, v in biz.items():
            lines.append(f"### {k}\n{v}\n")
    else:
        lines.append(f"{biz}\n")

    # 4. SWTO 分析
    lines.append("## 四、SWTO 分析\n")
    swto = data.get("swto", {})
    sections = [
        ("优势 (Strengths)", "S"),
        ("短板 (Weaknesses)", "W"),
        ("机会 (Opportunities)", "O"),
        ("威胁 (Threats)", "T"),
    ]
    for title, key in sections:
        items = swto.get(key, swto.get(title, []))
        if items:
            lines.append(f"### {title}\n")
            for i, item in enumerate(items, 1):
                lines.append(f"{i}. {item}")
            lines.append("")

    # 5. 客户风险扫描
    lines.append("## 五、客户风险扫描\n")
    risks = data.get("risks", {})
    lines.append(f"**整体评估**：{risk_badge(risks.get('overall_level', '🟢'))} {risks.get('suggestion', '')}")
    lines.append(f"**数据来源**：{risks.get('source', 'websearch')}\n")
    items = risks.get("items", [])
    if items:
        lines.append("| 风险类别 | 风险项 | 等级 | 说明 | 数据来源 |")
        lines.append("|----------|--------|:----:|------|---------|")
        for r in items:
            level = risk_badge(r.get("level", "🟢"))
            lines.append(f"| {r.get('category','')} | {r.get('item','')} | {level} | {r.get('detail','')} | {r.get('source','')} |")
        lines.append("")
    else:
        lines.append("未发现明显风险。\n")

    # 6. 痛点与需求分析
    lines.append("## 六、痛点与需求分析\n")
    pains = data.get("pain_points", [])
    if pains:
        for i, p in enumerate(pains, 1):
            lines.append(f"### 场景 {i}：{p.get('scenario', '')}\n")
            lines.append(f"- **痛点描述**：{p.get('pain', '')}")
            lines.append(f"- **影响**：{p.get('impact', '')}")
            lines.append(f"- **需求**：{p.get('need', '')}\n")
    else:
        lines.append("（分析中...）\n")

    # 7. 匹配方案建议
    lines.append("## 七、匹配方案建议\n")
    matches = data.get("solution_matches", [])
    if matches:
        lines.append("| 客户痛点 | 对应方案 | 预期价值 |")
        lines.append("|----------|---------|---------|")
        for m in matches:
            lines.append(f"| {m.get('pain','')} | {m.get('solution','')} | {m.get('value','')} |")
        lines.append("")
    else:
        lines.append("（基于已获取的客户信息进行匹配分析...）\n")

    # 8. 售前沟通策略
    lines.append("## 八、售前沟通策略\n")
    strategy = data.get("sales_strategy", {})
    if isinstance(strategy, dict):
        for k, v in strategy.items():
            lines.append(f"### {k}\n{v}\n")
    else:
        lines.append(f"{strategy}\n")

    # 9. 客户 FAQ 预测
    lines.append("## 九、客户 FAQ 预测\n")
    faqs = data.get("faq", [])
    if faqs:
        for i, faq in enumerate(faqs, 1):
            q = faq.get("question", "") if isinstance(faq, dict) else faq
            a = faq.get("answer", "") if isinstance(faq, dict) else ""
            lines.append(f"**Q{i}:** {q}")
            if a:
                lines.append(f"> {a}")
            lines.append("")
    else:
        lines.append("（待生成...）\n")

    # 10. 下一步行动
    lines.append("## 十、下一步行动\n")
    next_steps = data.get("next_steps", [])
    if next_steps:
        for i, step in enumerate(next_steps, 1):
            lines.append(f"{i}. {step}")
        lines.append("")

    # 备注
    notes = data.get("notes", "")
    if notes:
        lines.append("---\n")
        lines.append(f"*{notes}*\n")

    # 自定义模块
    custom = data.get("custom_sections", [])
    if custom:
        lines.append("---\n")
        for sec in custom:
            lines.append(f"## {sec.get('title', '')}\n")
            lines.append(f"{sec.get('content', '')}\n")

    return "\n".join(lines)


# ──────────────────────────────
# HTML 生成
# ──────────────────────────────

CSS = """
* { margin:0; padding:0; box-sizing:border-box; }
body {
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", sans-serif;
  background: #f5f7fa;
  color: #333;
  line-height: 1.8;
}
.container { max-width: 960px; margin: 0 auto; padding: 20px; }

/* 封面 */
.cover {
  background: linear-gradient(135deg, #1a73e8 0%, #0d47a1 100%);
  color: #fff;
  padding: 80px 40px;
  border-radius: 12px;
  margin-bottom: 32px;
  text-align: center;
}
.cover h1 { font-size: 28px; margin-bottom: 12px; line-height: 1.4; }
.cover .meta { font-size: 14px; opacity: .85; line-height: 1.8; }

/* 章节 */
.section {
  background: #fff;
  border-radius: 12px;
  padding: 28px 32px;
  margin-bottom: 20px;
  box-shadow: 0 1px 4px rgba(0,0,0,.06);
}
.section h2 {
  font-size: 20px;
  color: #1a73e8;
  margin-bottom: 16px;
  padding-bottom: 8px;
  border-bottom: 2px solid #e8f0fe;
  display: flex;
  align-items: center;
  gap: 8px;
}
.section h2 .num {
  display: inline-flex; align-items: center; justify-content: center;
  width: 28px; height: 28px; border-radius: 50%;
  background: #1a73e8; color: #fff;
  font-size: 14px; font-weight: 600;
  flex-shrink: 0;
}
.section h3 {
  font-size: 16px;
  color: #444;
  margin: 16px 0 8px;
}
.section p { margin: 8px 0; color: #555; }

/* 表格 */
table {
  width: 100%;
  border-collapse: collapse;
  margin: 12px 0;
  font-size: 14px;
}
th {
  background: #1a73e8;
  color: #fff;
  padding: 10px 12px;
  text-align: left;
  font-weight: 500;
}
td {
  padding: 10px 12px;
  border-bottom: 1px solid #eee;
}
tr:nth-child(even) td { background: #f8f9fb; }

/* 标签 */
.tag {
  display: inline-block; padding: 2px 12px; border-radius: 15px;
  font-size: 12px; font-weight: 500;
}
.tag-green { background: #e6f9ec; color: #1a7d36; }
.tag-yellow { background: #fff8e1; color: #856404; }
.tag-red { background: #fce4e4; color: #c62828; }

/* 风险 */
.risk-table td:first-child { font-weight: 500; white-space: nowrap; }

/* 卡片网格 */
.card-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin: 12px 0; }
.card {
  background: #f8f9fb; border-radius: 10px; padding: 16px;
  border-left: 4px solid #1a73e8;
}
.card h4 { font-size: 14px; color: #1a73e8; margin-bottom: 6px; }
.card p { font-size: 13px; color: #555; margin: 0; }

/* 列表 */
ol, ul { padding-left: 20px; margin: 8px 0; }
li { margin: 4px 0; color: #555; }

/* 引用块 */
blockquote {
  border-left: 4px solid #1a73e8;
  background: #f0f6ff;
  padding: 12px 16px;
  margin: 12px 0;
  border-radius: 0 8px 8px 0;
  color: #555;
}
.footer {
  text-align: center; font-size: 12px; color: #999; padding: 20px 0;
}
@media (max-width: 640px) {
  .card-grid { grid-template-columns: 1fr; }
  .cover { padding: 40px 20px; }
  .section { padding: 20px 16px; }
}
"""


def render_html(data, my_company):
    """生成 HTML 格式报告"""
    c = data.get("company_name", "目标公司")
    md_content = render_md(data, my_company)

    # 构建 HTML
    sections_html = []

    def esc(val):
        if val is None:
            return ""
        return html_module.escape(str(val))

    # 封面
    info_source = data.get("research_source", "websearch")
    source_label = {"qichacha": "企查查", "websearch": "网页搜索", "limited": "有限公开渠道"}
    cover = f"""<div class="cover">
      <h1>{esc(c)}<br>客户背调与售前咨询报告</h1>
      <div class="meta">
        <p>生成时间：{datetime.now().strftime('%Y-%m-%d %H:%M')}</p>
        <p>数据来源：{source_label.get(info_source, info_source)}</p>
      </div>
    </div>"""

    # 1. 客户概览
    bi = data.get("basic_info", {})
    table_rows = "\n".join(f"<tr><td>{esc(k)}</td><td>{esc(v)}</td></tr>" for k, v in bi.items())
    sections_html.append(f"""<div class="section">
      <h2><span class="num">1</span>客户概览</h2>
      <table><tbody>{table_rows}</tbody></table>
    </div>""")

    # 2. 股东与集团背景
    sh = esc(data.get("shareholder_structure", "暂无数据"))
    sections_html.append(f"""<div class="section">
      <h2><span class="num">2</span>股东与集团背景</h2>
      <p><strong>股权结构</strong>：{sh}</p>
    </div>""")

    # 3. 行业与业务分析
    biz = data.get("business", {})
    biz_html = ""
    if isinstance(biz, dict):
        for k, v in biz.items():
            biz_html += f"<h3>{esc(k)}</h3><p>{esc(v)}</p>"
    else:
        biz_html = f"<p>{esc(biz)}</p>"
    sections_html.append(f"""<div class="section">
      <h2><span class="num">3</span>行业与业务分析</h2>
      {biz_html}
    </div>""")

    # 4. SWTO
    swto = data.get("swto", {})
    swto_map = [
        ("优势 (Strengths)", "S"),
        ("短板 (Weaknesses)", "W"),
        ("机会 (Opportunities)", "O"),
        ("威胁 (Threats)", "T"),
    ]
    swto_html = ""
    for title, key in swto_map:
        items = swto.get(key, swto.get(title, []))
        if items:
            lis = "".join(f"<li>{esc(item)}</li>" for item in items)
            swto_html += f"<h3>{title}</h3><ul>{lis}</ul>"
    sections_html.append(f"""<div class="section">
      <h2><span class="num">4</span>SWTO 分析</h2>
      {swto_html}
    </div>""")

    # 5. 风险扫描
    risks = data.get("risks", {})
    ol = risks.get("overall_level", "🟢")
    sug = esc(risks.get("suggestion", ""))
    src = esc(risks.get("source", "websearch"))
    items = risks.get("items", [])
    risk_rows = ""
    for r in items:
        lv = r.get("level", "🟢")
        tag_cls = LEVEL_TAG_CLASS.get(lv, "tag-green")
        level_badge = f'<span class="tag {tag_cls}">{LEVEL_EMOJI.get(lv,lv)} {LEVEL_LABEL.get(lv,"")}</span>'
        risk_rows += f"<tr><td>{esc(r.get('category',''))}</td><td>{esc(r.get('item',''))}</td><td>{level_badge}</td><td>{esc(r.get('detail',''))}</td><td>{esc(r.get('source',''))}</td></tr>"

    risk_body = ""
    if risk_rows:
        risk_body = f"""<table class="risk-table">
          <thead><tr><th>风险类别</th><th>风险项</th><th>等级</th><th>说明</th><th>数据来源</th></tr></thead>
          <tbody>{risk_rows}</tbody>
        </table>"""
    else:
        risk_body = "<p>未发现明显风险。</p>"

    sections_html.append(f"""<div class="section">
      <h2><span class="num">5</span>客户风险扫描</h2>
      <p><strong>整体评估</strong>：<span class="tag {LEVEL_TAG_CLASS.get(ol,'tag-green')}">{LEVEL_EMOJI.get(ol,ol)} {LEVEL_LABEL.get(ol,"")}</span> {sug}</p>
      <p><strong>数据来源</strong>：{src}</p>
      {risk_body}
    </div>""")

    # 6. 痛点与需求
    pains = data.get("pain_points", [])
    pain_html = ""
    if pains:
        cards = ""
        for i, p in enumerate(pains, 1):
            cards += f"""<div class="card">
              <h4>场景 {i}：{esc(p.get('scenario',''))}</h4>
              <p><strong>痛点</strong>：{esc(p.get('pain',''))}</p>
              <p><strong>影响</strong>：{esc(p.get('impact',''))}</p>
              <p><strong>需求</strong>：{esc(p.get('need',''))}</p>
            </div>"""
        pain_html = f'<div class="card-grid">{cards}</div>'
    else:
        pain_html = "<p>（分析中...）</p>"
    sections_html.append(f"""<div class="section">
      <h2><span class="num">6</span>痛点与需求分析</h2>
      {pain_html}
    </div>""")

    # 7. 匹配方案
    matches = data.get("solution_matches", [])
    match_html = ""
    if matches:
        rows = "".join(f"<tr><td>{esc(m.get('pain',''))}</td><td>{esc(m.get('solution',''))}</td><td>{esc(m.get('value',''))}</td></tr>" for m in matches)
        match_html = f"""<table><thead><tr><th>客户痛点</th><th>对应方案</th><th>预期价值</th></tr></thead><tbody>{rows}</tbody></table>"""
    else:
        match_html = "<p>（基于已获取的客户信息进行匹配分析...）</p>"
    sections_html.append(f"""<div class="section">
      <h2><span class="num">7</span>匹配方案建议</h2>
      {match_html}
    </div>""")

    # 8. 售前沟通策略
    strategy = data.get("sales_strategy", {})
    strat_html = ""
    if isinstance(strategy, dict):
        for k, v in strategy.items():
            strat_html += f"<h3>{esc(k)}</h3><p>{esc(v)}</p>"
    else:
        strat_html = f"<p>{esc(strategy)}</p>"
    sections_html.append(f"""<div class="section">
      <h2><span class="num">8</span>售前沟通策略</h2>
      {strat_html}
    </div>""")

    # 9. FAQ
    faqs = data.get("faq", [])
    faq_html = ""
    if faqs:
        for i, faq in enumerate(faqs, 1):
            q = faq.get("question", "") if isinstance(faq, dict) else faq
            a = faq.get("answer", "") if isinstance(faq, dict) else ""
            faq_html += f"<h3>Q{i}: {esc(q)}</h3>"
            if a:
                faq_html += f"<blockquote>{esc(a)}</blockquote>"
    else:
        faq_html = "<p>（待生成...）</p>"
    sections_html.append(f"""<div class="section">
      <h2><span class="num">9</span>客户 FAQ 预测</h2>
      {faq_html}
    </div>""")

    # 10. 下一步
    steps = data.get("next_steps", [])
    steps_html = ""
    if steps:
        lis = "".join(f"<li>{esc(s)}</li>" for s in steps)
        steps_html = f"<ol>{lis}</ol>"
    sections_html.append(f"""<div class="section">
      <h2><span class="num">10</span>下一步行动</h2>
      {steps_html}
    </div>""")

    # 备注
    notes = data.get("notes", "")
    notes_html = ""
    if notes:
        notes_html = f'<div class="section" style="background:#fff8e1;"><p><em>{esc(notes)}</em></p></div>'

    # 自定义模块
    custom = data.get("custom_sections", [])
    custom_html = ""
    for sec in custom:
        custom_html += f"""<div class="section">
          <h2>{esc(sec.get('title',''))}</h2>
          <p>{esc(sec.get('content',''))}</p>
        </div>"""

    full_html = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{esc(c)} - 客户背调与售前咨询报告</title>
<style>{CSS}</style>
</head>
<body>
<div class="container">
{cover}
{"".join(sections_html)}
{notes_html}
{custom_html}
<div class="footer">
<p>Generated by wx-customer-insight-report | {datetime.now().strftime('%Y-%m-%d %H:%M')}</p>
</div>
</div>
</body>
</html>"""
    return full_html


# ──────────────────────────────
# 主入口
# ──────────────────────────────

def main():
    if len(sys.argv) < 2:
        print("Usage: python3 generate_report.py <report_data.json> [config.json] [output_dir]")
        sys.exit(1)

    report_path = sys.argv[1]
    config_path = sys.argv[2] if len(sys.argv) > 2 else default_skill_userdata("wx-customer-insight-report", "config.json")
    output_dir = sys.argv[3] if len(sys.argv) > 3 else os.getcwd()

    # 打印实际路径（调试时可确认跨平台兼容性）
    print(f"[INFO] 报告数据: {report_path}")
    print(f"[INFO] 配置文件: {config_path}")
    print(f"[INFO] 输出目录: {output_dir}")

    # 读取数据
    report_data = read_json(report_path)
    config_data = read_json(config_path)

    if not report_data:
        print("[ERROR] 报告数据为空，无法生成")
        sys.exit(1)

    my_company = config_data.get("my_company", {})
    company_name = report_data.get("company_name", "目标公司")
    slug = make_slug(company_name)

    os.makedirs(output_dir, exist_ok=True)

    # 生成 MD
    md = render_md(report_data, my_company)
    md_path = os.path.join(output_dir, f"{slug}-客户背调与售前报告.md")
    with open(md_path, "w", encoding="utf-8") as f:
        f.write(md)
    print(f"[OK] MD 报告: {md_path}")

    # 生成 HTML
    html = render_html(report_data, my_company)
    html_path = os.path.join(output_dir, f"{slug}-客户背调与售前报告.html")
    with open(html_path, "w", encoding="utf-8") as f:
        f.write(html)
    print(f"[OK] HTML 报告: {html_path}")


if __name__ == "__main__":
    main()
